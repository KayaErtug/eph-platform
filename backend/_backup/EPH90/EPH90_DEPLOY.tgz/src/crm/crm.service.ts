import { Injectable, NotFoundException, ForbiddenException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { LinaDistanceService } from '../lina/geo/lina-distance.service';
import { DeedOwnerViewer, getOfficeAdvisorIds, redactDeedOwnerInfo } from '../units/deed-owner-privacy';
import { PropertyCriteriaService } from '../property-criteria/property-criteria.service';
import {
  CARD_PROFILE_CODES,
  CARD_PROFILES,
  getCardProfileBinding,
} from '../property-card/property-card-profile.registry';
import {
  ActivityType,
  CustomerInterestPriority,
  CustomerPropertyRelation,
  CustomerPurchaseIntent,
  CustomerRole,
  CustomerStatus,
  Prisma,
  Role,
  TaskStatus,
  UnitStatus,
  UnitType,
} from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';

@Injectable()
export class CrmService {
  private readonly matchLogger = new Logger(CrmService.name);
  private interestMatchHandler?: (interestId: string) => Promise<void>;

  registerInterestMatchHandler(handler: (interestId: string) => Promise<void>) {
    this.interestMatchHandler = handler;
  }

  async refreshInterestMatches(interest: { id: string; isActive: boolean }) {
    if (!interest.isActive) return;
    try {
      if (!this.interestMatchHandler) throw new Error('Matching handler unavailable');
      await this.interestMatchHandler(interest.id);
    } catch {
      this.matchLogger.warn('CRM ihtiyacı kaydedildi; otomatik eşleştirme tamamlanamadı. Yeniden tarama gerekli.');
    }
  }

  constructor(
    private readonly prisma: PrismaService,
    private readonly linaDistanceService: LinaDistanceService,
    private readonly propertyCriteriaService: PropertyCriteriaService,
  ) {}

  private canAccessCustomer(customerOwnerId: string, userId: string, userRole: Role) {
    return userRole === Role.SUPER_ADMIN || customerOwnerId === userId;
  }

  private getCustomerWhere(userId: string, userRole: Role) {
    if (userRole === Role.SUPER_ADMIN) {
      return {};
    }

    return { ownerId: userId };
  }

  private normalizeStringArray(value: unknown): string[] | undefined {
    if (value === undefined) {
      return undefined;
    }

    if (!Array.isArray(value)) {
      return [];
    }

    return value
      .map((item) => String(item ?? '').trim())
      .filter(Boolean);
  }

  private normalizeEnumArray<T extends string>(value: unknown, allowedValues: readonly T[]): T[] | undefined {
    if (value === undefined) {
      return undefined;
    }

    if (!Array.isArray(value)) {
      return [];
    }

    const allowed = new Set<string>(allowedValues);

    return value
      .map((item) => String(item ?? '').trim())
      .filter((item): item is T => allowed.has(item));
  }

  private normalizeOptionalNumber(value: unknown): number | null | undefined {
    if (value === undefined) {
      return undefined;
    }

    if (value === null || value === '') {
      return null;
    }

    const numberValue = Number(value);

    if (Number.isNaN(numberValue)) {
      return null;
    }

    return numberValue;
  }

  private normalizeCardProfileCriteria(
    value: unknown,
    propertyTypes: readonly string[] | undefined,
  ): Prisma.InputJsonValue | typeof Prisma.DbNull | undefined {
    if (value === undefined) {
      return undefined;
    }

    if (value === null) {
      return Prisma.DbNull;
    }

    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      throw new BadRequestException('Kart kriterleri geçersiz.');
    }

    const record = value as Record<string, unknown>;
    const rawDemandGroupId = record.demandGroupId;
    const demandGroupId = rawDemandGroupId === undefined || rawDemandGroupId === null
      ? undefined
      : String(rawDemandGroupId).trim();
    if (demandGroupId && !/^[A-Za-z0-9_-]{8,128}$/.test(demandGroupId)) {
      throw new BadRequestException('Talep grubu kimliği geçersiz.');
    }
    const profileCode = String(record.profile ?? record.cardProfile ?? '')
      .trim()
      .toUpperCase();
    const allowedProfileCodes = new Set<string>(CARD_PROFILE_CODES);

    if (!allowedProfileCodes.has(profileCode)) {
      throw new BadRequestException(`Geçersiz CardProfile: ${profileCode || 'boş'}`);
    }

    const canonicalProfileCode =
      profileCode as (typeof CARD_PROFILE_CODES)[number];

    for (const propertyType of propertyTypes || []) {
      const binding = getCardProfileBinding(propertyType as UnitType);

      if (!binding || binding.profileCode !== canonicalProfileCode) {
        throw new BadRequestException(
          'Kart kriterleri seçilen gayrimenkul tipleriyle uyumlu değil.',
        );
      }
    }

    const rawValues = record.values;

    if (
      rawValues !== undefined &&
      (!rawValues || typeof rawValues !== 'object' || Array.isArray(rawValues))
    ) {
      throw new BadRequestException('CardProfile values alanı geçersiz.');
    }

    const valuesRecord = (rawValues || {}) as Record<string, unknown>;
    const values: Record<string, string[]> = {};
    const rawPriorities = record.priorities;
    if (
      rawPriorities !== undefined &&
      (!rawPriorities || typeof rawPriorities !== 'object' || Array.isArray(rawPriorities))
    ) {
      throw new BadRequestException('CardProfile priorities alanı geçersiz.');
    }
    const prioritiesRecord = (rawPriorities || {}) as Record<string, unknown>;
    const priorities: Record<string, 'MUST' | 'PREFERENCE' | 'ANY'> = {};

    for (const slot of CARD_PROFILES[canonicalProfileCode].slots) {
      const sourceKeys = Array.from(
        new Set([slot.key, ...slot.sourceKeys]),
      );

      for (const sourceKey of sourceKeys) {
        if (!(sourceKey in valuesRecord)) continue;

        const raw = valuesRecord[sourceKey];
        const normalized = (Array.isArray(raw) ? raw : [raw])
          .map((item) => String(item ?? '').trim())
          .filter(Boolean);
        const unique = Array.from(new Set(normalized));

        if (unique.length > 0) {
          values[slot.key] = unique;
          break;
        }
      }

      for (const sourceKey of sourceKeys) {
        if (!(sourceKey in prioritiesRecord)) continue;
        const priority = String(prioritiesRecord[sourceKey] ?? '').trim().toUpperCase();
        if (!['MUST', 'PREFERENCE', 'ANY'].includes(priority)) {
          throw new BadRequestException(`Geçersiz kriter önceliği: ${sourceKey}`);
        }
        priorities[slot.key] = priority as 'MUST' | 'PREFERENCE' | 'ANY';
        break;
      }
    }

    return {
      version: '1.3',
      profile: canonicalProfileCode,
      values,
      ...(rawPriorities === undefined ? {} : { priorities }),
      ...(demandGroupId ? { demandGroupId } : {}),
    } as Prisma.InputJsonValue;
  }

  private cleanCustomerData(data: any): Prisma.CustomerUncheckedCreateInput | Prisma.CustomerUncheckedUpdateInput {
    const allowedCustomerRoles = Object.values(CustomerRole);

    const cleaned: any = {
      firstName: data.firstName,
      lastName: data.lastName,
      phone: data.phone === undefined ? undefined : data.phone || null,
      email: data.email === undefined ? undefined : data.email || null,
      city: data.city === undefined ? undefined : data.city || null,
      profession: data.profession === undefined ? undefined : data.profession || null,
      company: data.company === undefined ? undefined : data.company || null,
      budget: this.normalizeOptionalNumber(data.budget),
      interestedArea: data.interestedArea === undefined ? undefined : data.interestedArea || null,
      interestedType: data.interestedType === undefined ? undefined : data.interestedType || null,
      source: data.source === undefined ? undefined : data.source || null,
      status: data.status,
      roles: this.normalizeEnumArray(data.roles, allowedCustomerRoles),
      tags: this.normalizeStringArray(data.tags),
      notes: data.notes === undefined ? undefined : data.notes || null,
      lastContactedAt: data.lastContactedAt ? new Date(data.lastContactedAt) : undefined,
    };

    Object.keys(cleaned).forEach((key) => {
      if (cleaned[key] === undefined) {
        delete cleaned[key];
      }
    });

    return cleaned;
  }

  private cleanInterestData(data: any): Prisma.CustomerInterestUncheckedCreateInput | Prisma.CustomerInterestUncheckedUpdateInput {
    const allowedUnitTypes = Object.values(UnitType);
    const allowedUnitStatuses = Object.values(UnitStatus);
    const allowedIntents = Object.values(CustomerPurchaseIntent);
    const allowedPriorities = Object.values(CustomerInterestPriority);

    const purchaseIntent = String(data.purchaseIntent ?? CustomerPurchaseIntent.BELIRSIZ);
    const priority = String(data.priority ?? CustomerInterestPriority.NORMAL);
    const propertyTypes = this.normalizeEnumArray(
      data.propertyTypes,
      allowedUnitTypes as string[],
    );

    const cleaned: any = {
      title: data.title ?? null,
      city: data.city ?? null,
      district: data.district ?? null,
      neighborhood: data.neighborhood ?? null,
      propertyTypes,
      statuses: this.normalizeEnumArray(data.statuses, allowedUnitStatuses as string[]),
      minBudget: this.normalizeOptionalNumber(data.minBudget),
      maxBudget: this.normalizeOptionalNumber(data.maxBudget),
      priceCurrency: data.priceCurrency ?? 'TRY',
      minArea: this.normalizeOptionalNumber(data.minArea),
      maxArea: this.normalizeOptionalNumber(data.maxArea),
      roomCounts: this.normalizeStringArray(data.roomCounts),
      features: this.normalizeStringArray(data.features),
      cardProfileCriteria: this.normalizeCardProfileCriteria(
        data.cardProfileCriteria,
        propertyTypes,
      ),
      purchaseIntent: allowedIntents.includes(purchaseIntent as CustomerPurchaseIntent)
        ? purchaseIntent
        : CustomerPurchaseIntent.BELIRSIZ,
      priority: allowedPriorities.includes(priority as CustomerInterestPriority) ? priority : CustomerInterestPriority.NORMAL,
      notes: data.notes ?? null,
      isActive: data.isActive,
      lastMatchedAt: data.lastMatchedAt ? new Date(data.lastMatchedAt) : undefined,
    };

    Object.keys(cleaned).forEach((key) => {
      if (cleaned[key] === undefined) {
        delete cleaned[key];
      }
    });

    return cleaned;
  }

  private async findCustomerForAccess(customerId: string, userId: string, userRole: Role, db: Prisma.TransactionClient = this.prisma) {
    const customer = await db.customer.findUnique({
      where: { id: customerId },
    });

    if (!customer) {
      throw new NotFoundException('Müşteri bulunamadı.');
    }

    if (!this.canAccessCustomer(customer.ownerId, userId, userRole)) {
      throw new ForbiddenException('Bu CRM kaydına erişim yetkiniz yok.');
    }

    return customer;
  }

  private async findInterestForAccess(interestId: string, userId: string, userRole: Role) {
    const interest = await this.prisma.customerInterest.findUnique({
      where: { id: interestId },
      include: { customer: true },
    });

    if (!interest) {
      throw new NotFoundException('İlgi bölgesi bulunamadı.');
    }

    if (!this.canAccessCustomer(interest.customer.ownerId, userId, userRole)) {
      throw new ForbiddenException('Bu CRM ilgi bölgesine erişim yetkiniz yok.');
    }

    return interest;
  }

  private async findCustomerPropertyForAccess(customerPropertyId: string, userId: string, userRole: Role) {
    const property = await this.prisma.customerProperty.findUnique({
      where: { id: customerPropertyId },
      include: { customer: true },
    });

    if (!property) {
      throw new NotFoundException('Müşteri-gayrimenkul ilişkisi bulunamadı.');
    }

    if (!this.canAccessCustomer(property.customer.ownerId, userId, userRole)) {
      throw new ForbiddenException('Bu müşteri-gayrimenkul ilişkisine erişim yetkiniz yok.');
    }

    return property;
  }

  // Müşteriye bağlı portföyde tapu sahibi bilgisi ilan sahibi danışmana, ofis sahibine ve süper admine döner.
  private redactPropertyUnits<
    T extends { unit?: { project?: { ownerId?: string | null } | null } | null },
  >(viewer: DeedOwnerViewer, officeAdvisorIds: Set<string>, properties: T[]): T[] {
    return properties.map((property) =>
      property.unit
        ? {
            ...property,
            unit: redactDeedOwnerInfo(
              property.unit,
              property.unit.project?.ownerId,
              viewer,
              officeAdvisorIds,
            ),
          }
        : property,
    );
  }

  async getCustomers(userId: string, userRole: Role) {
    const customers = await this.prisma.customer.findMany({
      where: this.getCustomerWhere(userId, userRole),
      include: {
        owner: { select: { firstName: true, lastName: true, role: true } },
        activities: { orderBy: { createdAt: 'desc' }, take: 1 },
        tasks: { where: { status: TaskStatus.BEKLIYOR }, orderBy: { dueDate: 'asc' } },
        interests: { where: { isActive: true }, orderBy: [{ priority: 'desc' }, { updatedAt: 'desc' }] },
        properties: { include: { unit: { include: { project: true } } }, take: 3 },
        _count: { select: { activities: true, tasks: true, interests: true, properties: true } },
      },
      orderBy: { updatedAt: 'desc' },
    });

    const officeAdvisorIds = await getOfficeAdvisorIds(this.prisma, userId);

    return customers.map((customer) => ({
      ...customer,
      properties: this.redactPropertyUnits({ id: userId, role: userRole }, officeAdvisorIds, customer.properties),
    }));
  }

  private async ensureActiveCrmCapacity(userId: string, tx?: Prisma.TransactionClient) {
    const client = tx || this.prisma;

    // 1. Ofis kontrolü: Kullanıcı bir ofise bağlıysa (üye veya sahip), tüm danışmanların toplamını say
    const user = await client.user.findUnique({
      where: { id: userId },
      select: { id: true, officeId: true },
    });

    let officeId = user?.officeId;
    if (!officeId) {
      const owned = await client.office.findFirst({
        where: { ownerUserId: userId, isActive: true },
        select: { id: true },
      });
      if (owned) officeId = owned.id;
    }

    if (officeId) {
      const office = await client.office.findUnique({
        where: { id: officeId },
        include: { users: { select: { id: true } } },
      });

      if (office) {
        const memberIds = Array.from(
          new Set([
            ...(office.ownerUserId ? [office.ownerUserId] : []),
            ...office.users.map((u) => u.id),
          ]),
        );

        const subSetting = await client.systemSetting.findUnique({
          where: { key: `OFFICE_SUBSCRIPTION_${office.id}` },
        });
        const sub: any = subSetting?.valueJson;
        const config = await client.systemSetting.findUnique({ where: { key: 'OFFICE_MEMBERSHIP_PACKAGES' } });
        const current: any = Array.isArray(config?.valueJson) ? config.valueJson.find((p: any) => p.code === sub?.packageCode) : undefined;
        const limit = Number(current?.crmCapacity ?? sub?.crmCapacity ?? 1500);
        const packageName = String(sub?.packageName || 'Ofis');

        const totalOfficeCustomers = await client.customer.count({
          where: { ownerId: { in: memberIds } },
        });

        if (limit >= 0 && totalOfficeCustomers >= limit) {
          throw new BadRequestException(
            `${packageName} paketinizde ofisinizin toplam aktif CRM kapasitesi ${limit}. ` +
              `Ofisteki tüm danışmanların mevcut toplam müşteri sayısı: ${totalOfficeCustomers}. ` +
              'Yeni müşteri eklenemiyor.',
          );
        }
        return;
      }
    }

    // 2. Bireysel danışman kontrolü
    const activeSub = await client.kullaniciUyelikPaketi.findFirst({
      where: {
        kullaniciId: userId,
        durum: 'AKTIF',
      },
      orderBy: { olusturulmaTarihi: 'desc' },
    });

    if (activeSub && activeSub.paketId) {
      const pkg = await client.uyelikPaketi.findUnique({
        where: { id: activeSub.paketId },
      });
      if (pkg) {
        const limit = pkg.aktifCrmLimiti ?? 100;
        const currentCount = await client.customer.count({
          where: { ownerId: userId },
        });
        if (limit >= 0 && currentCount >= limit) {
          throw new BadRequestException(
            `${pkg.paketAdi} paketinizde aktif CRM kapasiteniz ${limit}. ` +
              `Mevcut müşteri sayınız ${currentCount}. ` +
              'Yeni müşteri eklenemiyor.',
          );
        }
      }
    }
  }

  // CRM Madde 19 Form Detail Sync V3
  async createCustomer(userId: string, data: any, tx?: Prisma.TransactionClient) {
    await this.ensureActiveCrmCapacity(userId, tx);
    const normalizedCriteria = this.propertyCriteriaService.normalize({
      recordKind: 'DEMAND',
      source: 'CRM',
      areas: data?.interestAreas,
      propertyTypes: data?.propertyTypes,
      statuses: data?.interestStatuses,
      minBudget: data?.minBudget,
      maxBudget: data?.maxBudget,
      minArea: data?.minArea,
      maxArea: data?.maxArea,
      roomCounts: data?.roomCounts,
      features: data?.features,
      priceCurrency: data?.priceCurrency,
      isActive: true,
    });

    const interestAreas = normalizedCriteria.areas.filter(
      (area) => area.city && area.district,
    );

    const interestedArea =
      interestAreas.length > 0
        ? this.propertyCriteriaService.buildAreaSummary(interestAreas)
        : data?.interestedArea;

    const minBudget = normalizedCriteria.budget.min;
    const maxBudget = normalizedCriteria.budget.max;
    const minArea = normalizedCriteria.grossArea.min;
    const maxArea = normalizedCriteria.grossArea.max;
    const propertyTypes = normalizedCriteria.propertyTypes;
    const statuses = normalizedCriteria.statuses;
    const roomCounts = normalizedCriteria.roomCounts;
    const features = normalizedCriteria.features;
    const cardProfileCriteria = this.normalizeCardProfileCriteria(
      data?.cardProfileCriteria,
      propertyTypes,
    );

    const requestedIntent = String(
      data?.purchaseIntent ?? CustomerPurchaseIntent.BELIRSIZ,
    );
    const purchaseIntent = Object.values(CustomerPurchaseIntent).includes(
      requestedIntent as CustomerPurchaseIntent,
    )
      ? (requestedIntent as CustomerPurchaseIntent)
      : CustomerPurchaseIntent.BELIRSIZ;

    const requestedPriority = String(
      data?.priority ?? CustomerInterestPriority.NORMAL,
    );
    const priority = Object.values(CustomerInterestPriority).includes(
      requestedPriority as CustomerInterestPriority,
    )
      ? (requestedPriority as CustomerInterestPriority)
      : CustomerInterestPriority.NORMAL;

    const interestTitle = String(data?.interestTitle ?? '').trim();
    const interestNotes = String(data?.interestNotes ?? '').trim();

    const hasInterestProfileData = Boolean(
      interestAreas.length > 0 ||
        minBudget !== undefined && minBudget !== null ||
        maxBudget !== undefined && maxBudget !== null ||
        minArea !== undefined && minArea !== null ||
        maxArea !== undefined && maxArea !== null ||
        propertyTypes.length > 0 ||
        statuses.length > 0 ||
        roomCounts.length > 0 ||
        features.length > 0 ||
        (cardProfileCriteria !== undefined &&
          cardProfileCriteria !== Prisma.DbNull) ||
        interestTitle ||
        interestNotes ||
        purchaseIntent !== CustomerPurchaseIntent.BELIRSIZ ||
        priority !== CustomerInterestPriority.NORMAL,
    );

    const interestRows: Array<{
      city: string | null;
      district: string | null;
      neighborhood: string | null;
    }> =
      interestAreas.length > 0
        ? interestAreas
        : hasInterestProfileData
          ? [{ city: null, district: null, neighborhood: null }]
          : [];

    const persist = async (transaction: Prisma.TransactionClient) => {
      const customer = await transaction.customer.create({
        data: {
          ...this.cleanCustomerData({
            ...data,
            interestedArea,
          }),
          ownerId: userId,
        } as Prisma.CustomerUncheckedCreateInput,
      });

      if (interestRows.length > 0) {
        await transaction.customerInterest.createMany({
          data: interestRows.map((area) => {
            const locationTitle = [area.city, area.district, area.neighborhood]
              .filter(Boolean)
              .join(' / ');

            return {
              customerId: customer.id,
              title: interestTitle || locationTitle || 'Genel talep profili',
              city: area.city,
              district: area.district,
              neighborhood: area.neighborhood || null,
              propertyTypes,
              statuses,
              minBudget: minBudget ?? null,
              maxBudget: maxBudget ?? null,
              priceCurrency: normalizedCriteria.priceCurrency,
              minArea: minArea ?? null,
              maxArea: maxArea ?? null,
              roomCounts,
              features,
              cardProfileCriteria,
              purchaseIntent,
              priority,
              notes: interestNotes || null,
              isActive: true,
            };
          }),
        });
      }

      return transaction.customer.findUnique({
        where: { id: customer.id },
        include: {
          interests: {
            where: { isActive: true },
            orderBy: [{ priority: 'desc' }, { updatedAt: 'desc' }],
          },
        },
      });
    };
    return tx ? persist(tx) : this.prisma.$transaction(persist);
  }

  async getCustomer(id: string, userId: string, userRole: Role) {
    const customer = await this.prisma.customer.findUnique({
      where: { id },
      include: {
        owner: { select: { firstName: true, lastName: true, role: true } },
        activities: {
          include: { user: { select: { firstName: true, lastName: true } } },
          orderBy: { createdAt: 'desc' },
        },
        tasks: {
          include: { user: { select: { firstName: true, lastName: true } } },
          orderBy: { dueDate: 'asc' },
        },
        interests: { orderBy: [{ isActive: 'desc' }, { priority: 'desc' }, { updatedAt: 'desc' }] },
        properties: {
          include: {
            unit: {
              include: {
                project: true,
                images: { where: { isCover: true }, take: 1 },
              },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!customer) {
      throw new NotFoundException('Müşteri bulunamadı.');
    }

    if (!this.canAccessCustomer(customer.ownerId, userId, userRole)) {
      throw new ForbiddenException('Bu CRM kaydına erişim yetkiniz yok.');
    }

    const officeAdvisorIds = await getOfficeAdvisorIds(this.prisma, userId);

    return {
      ...customer,
      properties: this.redactPropertyUnits({ id: userId, role: userRole }, officeAdvisorIds, customer.properties),
    };
  }

  async uploadCustomerPhoto(
    customerId: string,
    userId: string,
    userRole: Role,
    file: Express.Multer.File,
  ) {
    await this.findCustomerForAccess(
      customerId,
      userId,
      userRole,
    );

    if (!file) {
      throw new BadRequestException(
        'Müşteri profil fotoğrafı seçilmedi.',
      );
    }

    const allowedTypes = [
      'image/jpeg',
      'image/png',
      'image/webp',
    ];

    if (!allowedTypes.includes(file.mimetype)) {
      throw new BadRequestException(
        'Sadece JPG, PNG veya WEBP yüklenebilir.',
      );
    }

    if (file.size > 5 * 1024 * 1024) {
      throw new BadRequestException(
        'Müşteri profil fotoğrafı 5MB den büyük olamaz.',
      );
    }

    const safeExt =
      file.mimetype === 'image/png'
        ? 'png'
        : file.mimetype === 'image/webp'
          ? 'webp'
          : 'jpg';

    const uploadDir = path.resolve(
      process.cwd(),
      'private',
      'crm-customer-images',
    );

    await fs.promises.mkdir(uploadDir, {
      recursive: true,
    });

    for (const extension of ['jpg', 'png', 'webp']) {
      const existingPath = path.join(
        uploadDir,
        `${customerId}.${extension}`,
      );

      try {
        await fs.promises.unlink(existingPath);
      } catch (error: any) {
        if (error?.code !== 'ENOENT') {
          throw error;
        }
      }
    }

    const filePath = path.join(
      uploadDir,
      `${customerId}.${safeExt}`,
    );

    await fs.promises.writeFile(
      filePath,
      file.buffer,
    );

    const photoUrl =
      `/api/crm/customers/${customerId}/photo-file`;

    return this.prisma.customer.update({
      where: { id: customerId },
      data: { photoUrl },
    });
  }

  async getCustomerPhotoFile(
    customerId: string,
    userId: string,
    userRole: Role,
  ) {
    const customer =
      await this.findCustomerForAccess(
        customerId,
        userId,
        userRole,
      );

    if (!customer.photoUrl) {
      throw new NotFoundException(
        'Müşteri profil fotoğrafı bulunamadı.',
      );
    }

    const uploadDir = path.resolve(
      process.cwd(),
      'private',
      'crm-customer-images',
    );

    for (const extension of ['jpg', 'png', 'webp']) {
      const candidate = path.join(
        uploadDir,
        `${customerId}.${extension}`,
      );

      if (fs.existsSync(candidate)) {
        return candidate;
      }
    }

    throw new NotFoundException(
      'Müşteri profil fotoğrafı bulunamadı.',
    );
  }

  async updateCustomer(id: string, userId: string, userRole: Role, data: any) {
    await this.findCustomerForAccess(id, userId, userRole);

    return this.prisma.customer.update({
      where: { id },
      data: this.cleanCustomerData(data) as Prisma.CustomerUncheckedUpdateInput,
    });
  }

  async updateStatus(id: string, userId: string, userRole: Role, status: CustomerStatus) {
    await this.findCustomerForAccess(id, userId, userRole);

    return this.prisma.customer.update({
      where: { id },
      data: { status, updatedAt: new Date() },
    });
  }

  async deleteCustomer(id: string, userId: string, userRole: Role) {
    await this.findCustomerForAccess(id, userId, userRole);

    return this.prisma.customer.delete({
      where: { id },
    });
  }

  async addActivity(customerId: string, userId: string, userRole: Role, data: { type: ActivityType; note: string }) {
    await this.findCustomerForAccess(customerId, userId, userRole);

    await this.prisma.customer.update({
      where: { id: customerId },
      data: { lastContactedAt: new Date() },
    });

    return this.prisma.activity.create({
      data: { customerId, userId, ...data },
    });
  }

  async addTask(customerId: string, userId: string, userRole: Role, data: { title: string; dueDate?: string }) {
    await this.findCustomerForAccess(customerId, userId, userRole);

    return this.prisma.task.create({
      data: {
        customerId,
        userId,
        title: data.title,
        dueDate: data.dueDate ? new Date(data.dueDate) : undefined,
      },
    });
  }

  async updateTask(taskId: string, userId: string, userRole: Role, data: { status?: TaskStatus; title?: string; dueDate?: string }) {
    const task = await this.prisma.task.findUnique({
      where: { id: taskId },
      include: { customer: true },
    });

    if (!task) {
      throw new NotFoundException('Görev bulunamadı.');
    }

    if (!this.canAccessCustomer(task.customer.ownerId, userId, userRole)) {
      throw new ForbiddenException('Bu CRM görevine erişim yetkiniz yok.');
    }

    return this.prisma.task.update({
      where: { id: taskId },
      data: {
        ...data,
        dueDate: data.dueDate ? new Date(data.dueDate) : undefined,
      },
    });
  }

  async getCustomerInterests(customerId: string, userId: string, userRole: Role) {
    await this.findCustomerForAccess(customerId, userId, userRole);

    return this.prisma.customerInterest.findMany({
      where: { customerId },
      orderBy: [{ isActive: 'desc' }, { priority: 'desc' }, { updatedAt: 'desc' }],
    });
  }

  async addCustomerInterest(customerId: string, userId: string, userRole: Role, data: any, tx?: Prisma.TransactionClient) {
    await this.findCustomerForAccess(customerId, userId, userRole, tx);

    const interest = await (tx || this.prisma).customerInterest.create({
      data: {
        ...this.cleanInterestData(data),
        customerId,
      } as Prisma.CustomerInterestUncheckedCreateInput,
    });
    if (!tx) await this.refreshInterestMatches(interest);
    return interest;
  }

  async updateCustomerInterest(interestId: string, userId: string, userRole: Role, data: any) {
    const existing = await this.findInterestForAccess(
      interestId,
      userId,
      userRole,
    );
    const normalizedData = {
      ...data,
      propertyTypes:
        data.propertyTypes ?? existing.propertyTypes,
    };

    const interest = await this.prisma.customerInterest.update({
      where: { id: interestId },
      data: this.cleanInterestData(
        normalizedData,
      ) as Prisma.CustomerInterestUncheckedUpdateInput,
    });
    await this.refreshInterestMatches(interest);
    return interest;
  }

  async deleteCustomerInterest(interestId: string, userId: string, userRole: Role) {
    await this.findInterestForAccess(interestId, userId, userRole);

    return this.prisma.customerInterest.update({
      where: { id: interestId },
      data: { isActive: false },
    });
  }

  async getCustomerProperties(customerId: string, userId: string, userRole: Role) {
    await this.findCustomerForAccess(customerId, userId, userRole);

    const properties = await this.prisma.customerProperty.findMany({
      where: { customerId },
      include: {
        unit: {
          include: {
            project: true,
            images: { where: { isCover: true }, take: 1 },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return this.redactPropertyUnits(
      { id: userId, role: userRole },
      await getOfficeAdvisorIds(this.prisma, userId),
      properties,
    );
  }

  async addCustomerProperty(
    customerId: string,
    userId: string,
    userRole: Role,
    data: { unitId: string; relationType: CustomerPropertyRelation; notes?: string },
  ) {
    await this.findCustomerForAccess(customerId, userId, userRole);

    if (!data.unitId) {
      throw new BadRequestException('Portföy seçiniz.');
    }

    const unit = await this.prisma.unit.findUnique({
      where: { id: data.unitId },
      include: { project: true },
    });

    if (!unit) {
      throw new NotFoundException('Portföy bulunamadı.');
    }

    const canUseUnit = userRole === Role.SUPER_ADMIN || unit.project.ownerId === userId || unit.isPoolVisible;

    if (!canUseUnit) {
      throw new ForbiddenException('Bu portföyü CRM kaydına bağlama yetkiniz yok.');
    }

    const property = await this.prisma.customerProperty.upsert({
      where: {
        customerId_unitId_relationType: {
          customerId,
          unitId: data.unitId,
          relationType: data.relationType,
        },
      },
      update: {
        notes: data.notes ?? null,
        updatedAt: new Date(),
      },
      create: {
        customerId,
        unitId: data.unitId,
        relationType: data.relationType,
        notes: data.notes ?? null,
      },
      include: {
        unit: {
          include: {
            project: true,
            images: { where: { isCover: true }, take: 1 },
          },
        },
      },
    });

    return (
      this.redactPropertyUnits(
        { id: userId, role: userRole },
        await getOfficeAdvisorIds(this.prisma, userId),
        [property],
      )
    )[0];
  }

  async deleteCustomerProperty(customerPropertyId: string, userId: string, userRole: Role) {
    await this.findCustomerPropertyForAccess(customerPropertyId, userId, userRole);

    return this.prisma.customerProperty.delete({
      where: { id: customerPropertyId },
    });
  }
   


  private getMatchLevel(score: number) {
    if (score >= 90) return 'Mükemmel';
    if (score >= 75) return 'Çok Güçlü';
    if (score >= 60) return 'Güçlü';
    if (score >= 40) return 'Uygun';
    return 'Zayıf';
  }

  private normalizeLocationText(value: unknown) {
    return String(value ?? '')
      .trim()
      .toLocaleLowerCase('tr-TR')
      .replace(/\s+/g, ' ');
  }

  private isSameLocationValue(left: unknown, right: unknown) {
    const normalizedLeft = this.normalizeLocationText(left);
    const normalizedRight = this.normalizeLocationText(right);

    return Boolean(
      normalizedLeft &&
        normalizedRight &&
        normalizedLeft === normalizedRight,
    );
  }

  private isNeighborhoodMatch(
    interestNeighborhood: unknown,
    projectAddress: unknown,
  ) {
    const neighborhood = this.normalizeLocationText(interestNeighborhood);
    const address = this.normalizeLocationText(projectAddress);

    if (!neighborhood || !address) {
      return false;
    }

    return (
      neighborhood === address ||
      address.includes(neighborhood) ||
      neighborhood.includes(address)
    );
  }

  private buildInterestDistancePoint(interest: {
    title?: string | null;
    city?: string | null;
    district?: string | null;
    neighborhood?: string | null;
  }) {
    const addressParts = [
      interest.neighborhood,
      interest.district,
      interest.city,
      'Türkiye',
    ].filter((value): value is string => Boolean(value?.trim()));

    if (addressParts.length <= 1) {
      return null;
    }

    return {
      label: interest.title?.trim() || 'CRM ilgi bölgesi',
      address: addressParts.join(', '),
      city: interest.city || undefined,
      district: interest.district || undefined,
      neighborhood: interest.neighborhood || undefined,
    };
  }

  private buildUnitDistancePoint(unit: {
    id: string;
    project?: {
      name?: string | null;
      city?: string | null;
      district?: string | null;
      address?: string | null;
      mapAddress?: string | null;
      placeId?: string | null;
      latitude?: number | null;
      longitude?: number | null;
    } | null;
  }) {
    const project = unit.project;

    if (!project) {
      return null;
    }

    const hasCoordinates =
      typeof project.latitude === 'number' &&
      Number.isFinite(project.latitude) &&
      typeof project.longitude === 'number' &&
      Number.isFinite(project.longitude);

    const address =
      project.mapAddress?.trim() ||
      [project.address, project.district, project.city, 'Türkiye']
        .filter((value): value is string => Boolean(value?.trim()))
        .join(', ');

    if (!hasCoordinates && !project.placeId?.trim() && !address) {
      return null;
    }

    return {
      label: project.name?.trim() || `Portföy ${unit.id.slice(0, 8)}`,
      latitude: hasCoordinates ? project.latitude ?? undefined : undefined,
      longitude: hasCoordinates ? project.longitude ?? undefined : undefined,
      address: address || undefined,
      city: project.city || undefined,
      district: project.district || undefined,
      neighborhood: project.address || undefined,
      placeId: project.placeId?.trim() || undefined,
    };
  }

  private getDistanceScore(distanceKm: number) {
    if (distanceKm <= 3) {
      return {
        score: 20,
        reason: `Araçla çok yakın (${distanceKm.toLocaleString('tr-TR')} km)`,
      };
    }

    if (distanceKm <= 7) {
      return {
        score: 18,
        reason: `Araçla yakın (${distanceKm.toLocaleString('tr-TR')} km)`,
      };
    }

    if (distanceKm <= 15) {
      return {
        score: 15,
        reason: `Araçla erişilebilir (${distanceKm.toLocaleString('tr-TR')} km)`,
      };
    }

    if (distanceKm <= 30) {
      return {
        score: 10,
        reason: `Araçla makul mesafe (${distanceKm.toLocaleString('tr-TR')} km)`,
      };
    }

    if (distanceKm <= 50) {
      return {
        score: 5,
        reason: `Araçla ${distanceKm.toLocaleString('tr-TR')} km`,
      };
    }

    return {
      score: 0,
      reason: `Araçla ${distanceKm.toLocaleString('tr-TR')} km`,
    };
  }

  private async mapWithConcurrency<T, R>(
    items: T[],
    concurrency: number,
    mapper: (item: T, index: number) => Promise<R>,
  ): Promise<R[]> {
    if (items.length === 0) {
      return [];
    }

    const results = new Array<R>(items.length);
    let cursor = 0;
    const workerCount = Math.max(
      1,
      Math.min(concurrency, items.length),
    );

    const workers = Array.from({ length: workerCount }, async () => {
      while (true) {
        const index = cursor;
        cursor += 1;

        if (index >= items.length) {
          return;
        }

        results[index] = await mapper(items[index], index);
      }
    });

    await Promise.all(workers);

    return results;
  }

  async getCustomerInterestMatches(
    interestId: string,
    userId: string,
    userRole: Role,
  ) {
    const interest = await this.findInterestForAccess(
      interestId,
      userId,
      userRole,
    );

    const poolUnits = await this.prisma.unit.findMany({
      where: {
        isPoolVisible: true,
      },
      include: {
        project: true,
        images: {
          where: {
            isCover: true,
          },
          take: 1,
        },
      },
      orderBy: {
        poolPublishedAt: 'desc',
      },
    });

    const preliminaryResults = poolUnits.map((unit) => {
      let score = 0;
      const reasons: string[] = [];

      const sameCity = this.isSameLocationValue(
        interest.city,
        unit.project?.city,
      );
      const sameDistrict = this.isSameLocationValue(
        interest.district,
        unit.project?.district,
      );
      const sameNeighborhood = this.isNeighborhoodMatch(
        interest.neighborhood,
        unit.project?.address,
      );

      if (sameCity) {
        score += 10;
        reasons.push('Aynı il');
      }

      if (sameDistrict) {
        score += 15;
        reasons.push('Aynı ilçe');
      }

      if (sameNeighborhood) {
        score += 15;
        reasons.push('Aynı mahalle');
      }

      if (
        Array.isArray(interest.propertyTypes) &&
        interest.propertyTypes.length > 0 &&
        interest.propertyTypes.includes(unit.type)
      ) {
        score += 10;
        reasons.push('Mülk tipi uyumlu');
      }

      if (
        Array.isArray(interest.statuses) &&
        interest.statuses.length > 0 &&
        interest.statuses.includes(unit.status)
      ) {
        score += 10;
        reasons.push('Portföy durumu uyumlu');
      }

      const minimumBudgetOk =
        !interest.minBudget ||
        unit.price >= interest.minBudget;

      const withinMaximumBudget =
        !interest.maxBudget ||
        unit.price <= interest.maxBudget;

      if (interest.maxBudget) {
        if (unit.price <= interest.maxBudget) {
          score += 10;
          reasons.push('Bütçeye uygun');
        }
      } else if (interest.minBudget && unit.price >= interest.minBudget) {
        score += 5;
        reasons.push('Bütçeye uygun');
      }

      if (
        interest.minArea &&
        interest.maxArea &&
        unit.area &&
        unit.area >= interest.minArea &&
        unit.area <= interest.maxArea
      ) {
        score += 5;
        reasons.push('m² uyumlu');
      }

      if (
        Array.isArray(interest.roomCounts) &&
        interest.roomCounts.length > 0 &&
        unit.roomCount &&
        interest.roomCounts.includes(unit.roomCount)
      ) {
        score += 3;
        reasons.push('Oda sayısı uyumlu');
      }

      const featureMatches =
        Array.isArray(interest.features) &&
        Array.isArray(unit.features)
          ? interest.features.filter((feature) =>
              unit.features.includes(feature),
            ).length
          : 0;

      if (featureMatches > 0) {
        score += 2;
        reasons.push(`${featureMatches} ortak özellik bulundu`);
      }

      return {
        unit,
        score,
        reasons,
        sameCity,
        distance: {
          decisionReady: false,
          drivingDistanceKm: null as number | null,
          durationMinutes: null as number | null,
          staticDurationMinutes: null as number | null,
          straightLineDistanceKm: null as number | null,
          detourFactor: null as number | null,
          roadNetworkBarrierSignal: false,
          errorCode: null as string | null,
          message: null as string | null,
        },
      };
    });

    const eligibleResults = preliminaryResults.filter((result) => {
      const unit = result.unit;

      // İl, talebin kesin coğrafi sınırıdır.
      if (interest.city && !result.sameCity) {
        return false;
      }

      // Seçili mülk tipi kesin eşleşme kriteridir.
      if (
        Array.isArray(interest.propertyTypes) &&
        interest.propertyTypes.length > 0 &&
        !interest.propertyTypes.includes(unit.type)
      ) {
        return false;
      }

      // Satılık / kiralık gibi durum tercihi varsa kesin uygulanır.
      if (
        Array.isArray(interest.statuses) &&
        interest.statuses.length > 0 &&
        !interest.statuses.includes(unit.status)
      ) {
        return false;
      }

      // Maksimum bütçede %30 tolerans uygulanır.
      // Bu sınırın üzerindeki portföyler eşleşmeye girmez.
      const maximumBudgetWithTolerance =
        interest.maxBudget
          ? interest.maxBudget * 1.3
          : null;

      if (
        maximumBudgetWithTolerance &&
        unit.price > maximumBudgetWithTolerance
      ) {
        return false;
      }

      // Eski kayıtlardaki minimum bütçe desteği korunur.
      if (
        interest.minBudget &&
        unit.price < interest.minBudget
      ) {
        return false;
      }

      return true;
    });

    const origin = this.buildInterestDistancePoint(interest);
    const distanceCandidates = origin
      ? eligibleResults
          .filter((result) => {
            const destination = this.buildUnitDistancePoint(result.unit);

            if (!destination) {
              return false;
            }

            if (interest.city) {
              return result.sameCity;
            }

            return true;
          })
          .sort((left, right) => right.score - left.score)
          .slice(0, 12)
      : [];

    await this.mapWithConcurrency(
      distanceCandidates,
      4,
      async (result) => {
        const destination = this.buildUnitDistancePoint(result.unit);

        if (!origin || !destination) {
          return;
        }

        try {
          const distanceResult: any =
            await this.linaDistanceService.calculate({
              origin,
              destination,
              routingPreference: 'TRAFFIC_AWARE',
              avoidFerries: true,
              avoidTolls: false,
              avoidHighways: false,
            });

          const decisionReady =
            distanceResult?.decision?.ready === true &&
            distanceResult?.driving?.available === true &&
            typeof distanceResult?.decision?.primaryDistanceKm === 'number';

          if (!decisionReady) {
            result.distance.errorCode =
              distanceResult?.driving?.errorCode || 'DRIVING_ROUTE_NOT_READY';
            result.distance.message =
              distanceResult?.driving?.message ||
              'Araç rotası alınamadığı için yakınlık kararı verilmedi.';
            return;
          }

          const drivingDistanceKm = Number(
            distanceResult.decision.primaryDistanceKm,
          );
          const distanceScore = this.getDistanceScore(drivingDistanceKm);

          result.score += distanceScore.score;
          result.reasons.push(distanceScore.reason);
          result.distance = {
            decisionReady: true,
            drivingDistanceKm,
            durationMinutes:
              typeof distanceResult?.driving?.durationMinutes === 'number'
                ? distanceResult.driving.durationMinutes
                : null,
            staticDurationMinutes:
              typeof distanceResult?.driving?.staticDurationMinutes ===
              'number'
                ? distanceResult.driving.staticDurationMinutes
                : null,
            straightLineDistanceKm:
              typeof distanceResult?.straightLine?.distanceKm === 'number'
                ? distanceResult.straightLine.distanceKm
                : null,
            detourFactor:
              typeof distanceResult?.comparison?.detourFactor === 'number'
                ? distanceResult.comparison.detourFactor
                : null,
            roadNetworkBarrierSignal:
              distanceResult?.comparison?.roadNetworkBarrierSignal === true,
            errorCode: null,
            message: null,
          };
        } catch (error) {
          result.distance.errorCode = 'DISTANCE_ENGINE_ERROR';
          result.distance.message =
            error instanceof Error
              ? error.message
              : 'Mesafe motoru çalıştırılamadı.';
        }
      },
    );

    await this.prisma.customerInterest.update({
      where: {
        id: interest.id,
      },
      data: {
        lastMatchedAt: new Date(),
      },
    });

    return eligibleResults
      .map((result) => {
        const unit = result.unit;
        const matchScore = Math.min(result.score, 100);

        return {
          unitId: unit.id,
          projectName: unit.project?.name,
          city: unit.project?.city,
          district: unit.project?.district,
          neighborhood: unit.project?.address,
          price: unit.price,
          roomCount: unit.roomCount,
          area: unit.area,
          coverImage: unit.images?.[0]?.url || null,
          matchScore,
          matchLevel: this.getMatchLevel(matchScore),
          matchReasons: result.reasons,
          distance: result.distance,
        };
      })
      .sort((left, right) => right.matchScore - left.matchScore);
  }



  async getAdminSummary(userRole: Role) {
    const normalizedRole = String(userRole || '').toUpperCase();




    const allowedRoles = ['ADMIN', 'SUPER_ADMIN', 'MODERATOR'];

     if (!allowedRoles.includes(normalizedRole)) {



      throw new ForbiddenException('CRM yönetim özetine erişim yetkiniz yok.');
    }

    const [
      totalCustomers,
      activeCustomers,
      closedDeals,
      lostDeals,
      pendingTasks,
      totalTasks,
      totalActivities,
      totalInterests,
      totalCustomerProperties,
    ] = await Promise.all([
      this.prisma.customer.count(),
      this.prisma.customer.count({
        where: {
          status: {
            notIn: [CustomerStatus.KAPANDI, CustomerStatus.KAYBEDILDI],
          },
        },
      }),
      this.prisma.customer.count({ where: { status: CustomerStatus.KAPANDI } }),
      this.prisma.customer.count({ where: { status: CustomerStatus.KAYBEDILDI } }),
      this.prisma.task.count({ where: { status: TaskStatus.BEKLIYOR } }),
      this.prisma.task.count(),
      this.prisma.activity.count(),
      this.prisma.customerInterest.count({ where: { isActive: true } }),
      this.prisma.customerProperty.count(),
    ]);

    return {
      totalCustomers,
      activeCustomers,
      closedDeals,
      lostDeals,
      pendingTasks,
      totalTasks,
      totalActivities,
      totalInterests,
      totalCustomerProperties,
    };
  }


  async getAdminPerformance(userRole: Role) {
    const normalizedRole = String(userRole || '').toUpperCase();
    const allowedRoles = ['ADMIN', 'SUPER_ADMIN', 'MODERATOR'];

    if (!allowedRoles.includes(normalizedRole)) {
      throw new ForbiddenException('CRM performans özetine erişim yetkiniz yok.');
    }

    const [offices, users, customerGroups, closedCustomerGroups, pendingTaskGroups, activityGroups, units] = await Promise.all([
      this.prisma.office.findMany({
        where: { isActive: true },
        select: {
          id: true,
          name: true,
          city: true,
          district: true,
          users: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              role: true,
            },
          },
          teams: {
            where: { isActive: true },
            select: {
              id: true,
              name: true,
              leader: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                },
              },
              members: {
                where: { isActive: true },
                select: {
                  userId: true,
                  user: {
                    select: {
                      id: true,
                      firstName: true,
                      lastName: true,
                      role: true,
                    },
                  },
                },
              },
            },
          },
        },
        orderBy: { createdAt: 'asc' },
      }),
      this.prisma.user.findMany({
        where: {
          role: {
            in: [Role.EMLAKCI, Role.MUTEAHHIT, Role.INSAAT_FIRMASI],
          },
        },
        select: {
          id: true,
          firstName: true,
          lastName: true,
          role: true,
          office: {
            select: {
              id: true,
              name: true,
              city: true,
              district: true,
            },
          },
        },
      }),
      this.prisma.customer.groupBy({
        by: ['ownerId'],
        _count: { _all: true },
      }),
      this.prisma.customer.groupBy({
        by: ['ownerId'],
        where: { status: CustomerStatus.KAPANDI },
        _count: { _all: true },
      }),
      this.prisma.task.groupBy({
        by: ['userId'],
        where: { status: TaskStatus.BEKLIYOR },
        _count: { _all: true },
      }),
      this.prisma.activity.groupBy({
        by: ['userId'],
        _count: { _all: true },
      }),
      this.prisma.unit.findMany({
        select: {
          id: true,
          isPoolVisible: true,
          project: {
            select: {
              ownerId: true,
            },
          },
        },
      }),
    ]);

    const customerCountByUser = new Map(customerGroups.map((item) => [item.ownerId, item._count._all]));
    const closedCountByUser = new Map(closedCustomerGroups.map((item) => [item.ownerId, item._count._all]));
    const pendingTaskCountByUser = new Map(pendingTaskGroups.map((item) => [item.userId, item._count._all]));
    const activityCountByUser = new Map(activityGroups.map((item) => [item.userId, item._count._all]));
    const portfolioCountByUser = new Map<string, number>();
    const poolPortfolioCountByUser = new Map<string, number>();

    units.forEach((unit) => {
      const ownerId = unit.project?.ownerId;
      if (!ownerId) return;

      portfolioCountByUser.set(ownerId, (portfolioCountByUser.get(ownerId) || 0) + 1);

      if (unit.isPoolVisible) {
        poolPortfolioCountByUser.set(ownerId, (poolPortfolioCountByUser.get(ownerId) || 0) + 1);
      }
    });

    const sumForUsers = (userIds: string[], source: Map<string, number>) =>
      userIds.reduce((total, userId) => total + (source.get(userId) || 0), 0);

    const calculateScore = (input: {
      customerCount: number;
      closedCount: number;
      activityCount: number;
      portfolioCount: number;
      poolPortfolioCount: number;
      memberCount?: number;
    }) => {
      const customerScore = Math.min(25, input.customerCount * 0.75);
      const closedScore = Math.min(25, input.closedCount * 2.5);
      const activityScore = Math.min(20, input.activityCount * 0.65);
      const portfolioScore = Math.min(20, input.portfolioCount * 0.65);
      const poolScore = Math.min(10, input.poolPortfolioCount * 1.2);
      const memberBonus = Math.min(8, (input.memberCount || 0) * 0.6);

      return Math.max(0, Math.min(100, Math.round(customerScore + closedScore + activityScore + portfolioScore + poolScore + memberBonus)));
    };

    const officePerformance = offices
      .map((office) => {
        const userIds = office.users.map((item) => item.id);
        const customerCount = sumForUsers(userIds, customerCountByUser);
        const closedCount = sumForUsers(userIds, closedCountByUser);
        const pendingTaskCount = sumForUsers(userIds, pendingTaskCountByUser);
        const activityCount = sumForUsers(userIds, activityCountByUser);
        const portfolioCount = sumForUsers(userIds, portfolioCountByUser);
        const poolPortfolioCount = sumForUsers(userIds, poolPortfolioCountByUser);

        return {
          id: office.id,
          name: office.name,
          location: [office.city, office.district].filter(Boolean).join(' / ') || 'Konum yok',
          advisorCount: office.users.length,
          teamCount: office.teams.length,
          customerCount,
          closedCount,
          pendingTaskCount,
          activityCount,
          portfolioCount,
          poolPortfolioCount,
          performanceScore: calculateScore({
            customerCount,
            closedCount,
            activityCount,
            portfolioCount,
            poolPortfolioCount,
            memberCount: office.users.length,
          }),
        };
      })
      .sort((a, b) => b.performanceScore - a.performanceScore || b.customerCount - a.customerCount)
      .slice(0, 5);

    const teamPerformance = offices
      .flatMap((office) =>
        office.teams.map((team) => {
          const userIds = team.members.map((member) => member.userId);
          const customerCount = sumForUsers(userIds, customerCountByUser);
          const closedCount = sumForUsers(userIds, closedCountByUser);
          const pendingTaskCount = sumForUsers(userIds, pendingTaskCountByUser);
          const activityCount = sumForUsers(userIds, activityCountByUser);
          const portfolioCount = sumForUsers(userIds, portfolioCountByUser);
          const poolPortfolioCount = sumForUsers(userIds, poolPortfolioCountByUser);

          return {
            id: team.id,
            name: team.name,
            officeName: office.name,
            leaderName: [team.leader?.firstName, team.leader?.lastName].filter(Boolean).join(' ') || 'Lider yok',
            memberCount: team.members.length,
            customerCount,
            closedCount,
            pendingTaskCount,
            activityCount,
            portfolioCount,
            poolPortfolioCount,
            performanceScore: calculateScore({
              customerCount,
              closedCount,
              activityCount,
              portfolioCount,
              poolPortfolioCount,
              memberCount: team.members.length,
            }),
          };
        }),
      )
      .sort((a, b) => b.performanceScore - a.performanceScore || b.customerCount - a.customerCount)
      .slice(0, 5);

    const teamNameByUserId = new Map<string, string>();

    offices.forEach((office) => {
      office.teams.forEach((team) => {
        team.members.forEach((member) => {
          if (!teamNameByUserId.has(member.userId)) {
            teamNameByUserId.set(member.userId, team.name);
          }
        });
      });
    });

    const advisorPerformance = users
      .map((advisor) => {
        const customerCount = customerCountByUser.get(advisor.id) || 0;
        const closedCount = closedCountByUser.get(advisor.id) || 0;
        const pendingTaskCount = pendingTaskCountByUser.get(advisor.id) || 0;
        const activityCount = activityCountByUser.get(advisor.id) || 0;
        const portfolioCount = portfolioCountByUser.get(advisor.id) || 0;
        const poolPortfolioCount = poolPortfolioCountByUser.get(advisor.id) || 0;

        return {
          id: advisor.id,
          name: [advisor.firstName, advisor.lastName].filter(Boolean).join(' ') || 'Danışman',
          role: advisor.role,
          officeName: advisor.office?.name || 'Ofis yok',
          teamName: teamNameByUserId.get(advisor.id) || 'Takım yok',
          customerCount,
          closedCount,
          pendingTaskCount,
          activityCount,
          portfolioCount,
          poolPortfolioCount,
          performanceScore: calculateScore({
            customerCount,
            closedCount,
            activityCount,
            portfolioCount,
            poolPortfolioCount,
          }),
        };
      })
      .filter((advisor) => advisor.customerCount > 0 || advisor.portfolioCount > 0 || advisor.activityCount > 0)
      .sort((a, b) => b.performanceScore - a.performanceScore || b.customerCount - a.customerCount)
      .slice(0, 10);

    return {
      officePerformance,
      teamPerformance,
      advisorPerformance,
    };
  }



  async getPipeline(userId: string, userRole: Role) {
    const customers = await this.prisma.customer.findMany({
      where: this.getCustomerWhere(userId, userRole),
      select: {
        id: true,
        firstName: true,
        lastName: true,
        phone: true,
        budget: true,
        status: true,
        roles: true,
        tags: true,
        city: true,
        lastContactedAt: true,
        updatedAt: true,
        _count: { select: { activities: true, tasks: true, interests: true, properties: true } },
      },
      orderBy: { updatedAt: 'desc' },
    });

    const pipeline: Record<string, any[]> = {};
    const statuses = [
      'YENI_LEAD',
      'ILK_GORUSME',
      'PORTFOLYO_GONDERILDI',
      'YER_GOSTERIMI',
      'TEKLIF_SURECI',
      'PAZARLIK',
      'KAPANDI',
      'KAYBEDILDI',
    ];

    statuses.forEach((status) => {
      pipeline[status] = [];
    });

    customers.forEach((customer) => {
      pipeline[customer.status]?.push(customer);
    });

    return pipeline;
  }
}
