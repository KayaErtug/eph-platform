import { assertLinaBudget } from "../lina-chat-budget.service";
import { Injectable } from "@nestjs/common";
import {
  ActivityType,
  CustomerInterestPriority,
  CustomerPurchaseIntent,
  CustomerRole,
  CustomerStatus,
  Role,
  TaskStatus,
  UnitStatus,
  UnitType,
} from "@prisma/client";

import { CrmService } from "../../crm/crm.service";
import { PrismaService } from "../../prisma/prisma.service";
import { randomUUID } from "node:crypto";
import { resolveOfficeWallet } from "../../office/office-wallet.rules";
import { readCost } from "../../pricing/commercial-costs";
import { NetworkService } from "../../network/network.service";
import { getCardProfileBinding } from "../../property-card/property-card-profile.registry";
import { LinaAuditService } from "../lina-audit.service";
import { LinaNetworkRequestDraftService } from "../lina-network-request-draft.service";
import type { LinaGateConfirmedDelete } from './lina-confirmation-gate.service';
import {
  LinaActionExecutionResult,
  LinaActionHistoryItem,
  LinaActionSourceModule,
  LinaActionUser,
  LinaPendingAction,
  LinaResolvedUser,
} from "./lina-action.types";

type CustomerLike = {
  id: string;
  firstName: string;
  lastName: string;
  phone?: string | null;
  email?: string | null;
  city?: string | null;
  budget?: number | null;
  status?: CustomerStatus;
  roles?: CustomerRole[];
  notes?: string | null;
  interests?: Array<{
    id: string;
    city?: string | null;
    district?: string | null;
    neighborhood?: string | null;
    propertyTypes?: UnitType[];
    statuses?: UnitStatus[];
    maxBudget?: number | null;
    roomCounts?: string[];
    purchaseIntent?: CustomerPurchaseIntent;
    isActive?: boolean;
  }>;
  tasks?: Array<{
    id: string;
    title: string;
    status: TaskStatus;
    dueDate?: Date | string | null;
  }>;
};

type ParsedCustomerFields = {
  firstName?: string;
  lastName?: string;
  phone?: string;
  email?: string;
  city?: string;
  budget?: number;
  notes?: string;
};

type NetworkCreateInput = Parameters<NetworkService["create"]>[0];

// Onay planı: kullanıcıya gösterilen nihai payload, ücret ve cüzdan kaynağı DB'de saklanır.
// Onaydan sonra AI ile yeniden çıkarım yapılmaz; payload aynen NetworkService.create'e gider.
type PendingNetworkRequestCreation = {
  planId?: string;
  userId: string;
  createdAt: number;
  expiresAt: number;
  sourceModule: LinaActionSourceModule;
  sourceText?: string;
  payload?: NetworkCreateInput;
  costPk?: number;
  baseCostPk?: number;
  urgentExtraPk?: number;
  walletSource?: "PERSONAL" | "OFFICE";
  walletOfficeId?: string | null;
  walletLabel?: string;
};


const PENDING_ACTION_TTL_MS = 5 * 60 * 1000;
// Bekleyen onaylar süreç belleğinde değil DB'de (LinaTaslak) tutulur; PM2 yeniden başlasa da kaybolmaz.
const PENDING_ACTION_KIND = "MOTOR_AKSIYON";
const PENDING_NETWORK_KIND = "MOTOR_TALEP_MERKEZI";

@Injectable()
export class LinaActionEngineService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly crmService: CrmService,
    private readonly networkService: NetworkService,
    private readonly linaNetworkRequestDraftService: LinaNetworkRequestDraftService,
    private readonly linaAuditService: LinaAuditService,
  ) {}

  private async loadPending<T extends { expiresAt: number }>(userId: string, kind: string): Promise<T | null> {
    const row = await this.prisma.linaTaslak.findFirst({
      where: { kullaniciId: userId, tur: kind, durum: "AKTIF" },
      orderBy: { guncellenmeTarihi: "desc" },
    });
    return row ? (row.alanlar as unknown as T) : null;
  }

  private async savePending(userId: string, kind: string, payload: { expiresAt: number; [key: string]: unknown }): Promise<void> {
    await this.dropPending(userId, kind);
    await this.prisma.linaTaslak.create({
      data: {
        kullaniciId: userId,
        tur: kind,
        durum: "AKTIF",
        alanlar: payload as never,
        gecerlilikTarihi: new Date(payload.expiresAt),
      },
    });
  }

  private async dropPending(userId: string, kind: string): Promise<void> {
    await this.prisma.linaTaslak.updateMany({
      where: { kullaniciId: userId, tur: kind, durum: "AKTIF" },
      data: { durum: "KAPANDI" },
    });
  }

  async tryExecute(
    rawMessage: string,
    rawUser: LinaActionUser | undefined,
    sourceModule: LinaActionSourceModule = "general",
    rawHistory: LinaActionHistoryItem[] = [],
    confirmedDelete?: LinaGateConfirmedDelete,
  ): Promise<LinaActionExecutionResult> {
    const message = String(rawMessage || "").trim();
    const history = this.normalizeHistory(rawHistory);

    if (!message) {
      return { handled: false };
    }

    const user = this.resolveUser(rawUser);

    if (!user) {
      if (this.looksLikePlatformAction(message)) {
        return {
          handled: true,
          success: false,
          message: "Bu işlemi yapabilmem için EPH Platform hesabınızla giriş yapmanız gerekir.",
        };
      }

      return { handled: false };
    }

    assertLinaBudget();
    const confirmationResult = await this.handlePendingConfirmation(
      message,
      user,
      sourceModule,
    );

    if (confirmationResult.handled) {
      return confirmationResult;
    }

    try {
      const networkRequestPrepare = await this.prepareNetworkRequestCreate(
        message,
        user,
        sourceModule,
        history,
      );

      if (networkRequestPrepare) {
        return networkRequestPrepare;
      }

      if (this.isInformationalQuestion(message)) {
        return { handled: false };
      }

      if (this.isCrmCustomerListCommand(message)) {
        return await this.listCrmCustomers(user, sourceModule);
      }

      if (this.isCrmCustomerFindCommand(message)) {
        return await this.findCrmCustomer(message, user, sourceModule);
      }

      if (this.isCrmCustomerDeleteCommand(message)) {
        return await this.prepareDeleteCrmCustomer(message, user, sourceModule, confirmedDelete);
      }

      if (this.isCrmStatusUpdateCommand(message)) {
        return await this.updateCrmCustomerStatus(message, user, sourceModule);
      }

      if (this.isCrmTaskCreateCommand(message)) {
        return await this.createCrmTask(message, user, sourceModule);
      }

      if (this.isCrmActivityCreateCommand(message)) {
        return await this.createCrmActivity(message, user, sourceModule);
      }

      assertLinaBudget();
      if (this.isCrmCustomerUpdateCommand(message)) {
        return await this.updateCrmCustomer(message, user, sourceModule);
      }

      return { handled: false };
    } catch (error) {
      const reason =
        error instanceof Error ? error.message : "Lina işlem motorunda bilinmeyen hata oluştu.";

      this.audit(user, sourceModule, "lina_action_engine", "error", reason, 2);

      return {
        handled: true,
        success: false,
        message: "İşlem şu anda tamamlanamadı. Lütfen tekrar deneyin.",
      };
    }
  }

  private resolveUser(user?: LinaActionUser): LinaResolvedUser | null {
    const id = String(user?.id || "").trim();
    const roleValue = String(user?.role || "")
      .trim()
      .toUpperCase()
      .replaceAll("İ", "I")
      .replaceAll("Ü", "U")
      .replaceAll("Ğ", "G")
      .replaceAll("Ş", "S")
      .replaceAll("Ö", "O")
      .replaceAll("Ç", "C");

    const roleMap: Record<string, Role> = {
      EMLAKCI: Role.EMLAKCI,
      MUTEAHHIT: Role.MUTEAHHIT,
      INSAAT_FIRMASI: Role.INSAAT_FIRMASI,
      ADMIN: Role.ADMIN,
      SUPER_ADMIN: Role.SUPER_ADMIN,
      SUPERADMIN: Role.SUPER_ADMIN,
      MODERATOR: Role.MODERATOR,
    };

    const role = roleMap[roleValue];

    if (!id || !role) {
      return null;
    }

    return {
      id,
      role,
      email: user?.email,
    };
  }

  private normalizeHistory(
    history: LinaActionHistoryItem[],
  ): LinaActionHistoryItem[] {
    if (!Array.isArray(history)) {
      return [];
    }

    return history
      .slice(-20)
      .map((item) => ({
        role:
          item?.role === "assistant"
            ? ("assistant" as const)
            : ("user" as const),
        content: String(item?.content || "").trim(),
      }))
      .filter((item) => item.content.length > 0);
  }

  private crmRoleListLabel(roles: CustomerRole[]): string {
    if (roles.length === 0) {
      return "Belirtilmedi";
    }

    return roles.map((role) => this.crmRoleLabel(role)).join(", ");
  }

  private crmRoleLabel(role: CustomerRole): string {
    const labels: Record<CustomerRole, string> = {
      [CustomerRole.ALICI]: "Alıcı",
      [CustomerRole.SATICI]: "Satıcı",
      [CustomerRole.KIRACI]: "Kiracı",
      [CustomerRole.MAL_SAHIBI]: "Mal Sahibi / Kiraya Veren",
      [CustomerRole.YATIRIMCI]: "Yatırımcı",
      [CustomerRole.MUTEAHHIT]: "Müteahhit",
      [CustomerRole.INSAAT_FIRMASI]: "İnşaat Firması",
      [CustomerRole.ARSA_SAHIBI]: "Arsa Sahibi",
    };

    return labels[role] || role;
  }
  private formatBudgetRange(
    minBudget?: number,
    maxBudget?: number,
  ): string {
    const format = (value: number) =>
      `${new Intl.NumberFormat("tr-TR").format(value)} ₺`;

    if (minBudget && maxBudget) {
      return `${format(minBudget)} – ${format(maxBudget)}`;
    }

    if (maxBudget) {
      return `En fazla ${format(maxBudget)}`;
    }

    if (minBudget) {
      return `En az ${format(minBudget)}`;
    }

    return "Belirtilmedi";
  }
  private propertyTypeLabel(type: UnitType): string {
    const labels: Partial<Record<UnitType, string>> = {
      [UnitType.DAIRE]: "Daire",
      [UnitType.VILLA]: "Villa",
      [UnitType.REZIDANS]: "Rezidans",
      [UnitType.MUSTAK_EV]: "Müstakil Ev",
      [UnitType.DUKKAN_MAGAZA]: "Dükkan / Mağaza",
      [UnitType.OFIS_BURO]: "Ofis / Büro",
      [UnitType.ARSA]: "Arsa",
      [UnitType.TARLA]: "Tarla",
    };

    return labels[type] || String(type).replaceAll("_", " ");
  }

  private async prepareNetworkRequestCreate(
    message: string,
    user: LinaResolvedUser,
    sourceModule: LinaActionSourceModule,
    history: LinaActionHistoryItem[],
  ): Promise<LinaActionExecutionResult | null> {
    const normalized = this.normalize(message);

    const mentionsRequestCenter =
      normalized.includes("talep merkezi") ||
      normalized.includes("talep merkezine");

    const explicitSave = /(kaydet|olustur|ekle)/.test(normalized);

    if (!mentionsRequestCenter || !explicitSave) {
      return null;
    }

    const sourceText = this.findNetworkRequestSourceText(
      history,
      message,
    );

    if (!sourceText) {
      return {
        handled: true,
        success: false,
        message:
          "Talep Merkezi kaydı için önceki talep metnini bulamadım. Talebinizi kriterleriyle birlikte tekrar yazın.",
      };
    }

    // Çıkarım yalnız burada, onaydan ÖNCE yapılır; kullanıcı nihai içeriği ve ücreti görerek onaylar.
    const draftResult = await this.linaNetworkRequestDraftService.create(
      sourceText,
    );
    const draft = draftResult.draft;

    if (
      !draft.category ||
      !draft.requestIntent ||
      !draft.propertyType ||
      !draft.city
    ) {
      return {
        handled: true,
        success: false,
        message:
          "Talep Merkezi kaydı için kategori, talep türü, gayrimenkul tipi veya şehir eksik. Talebinizi bu bilgilerle tekrar yazın.",
      };
    }

    const binding = getCardProfileBinding(draft.propertyType);
    const profileValues = draft.profileCriteria || {};
    const cardProfileCriteria =
      binding && Object.keys(profileValues).length > 0
        ? {
            version: "1.3",
            profile: binding.profileCode,
            values: profileValues,
          }
        : undefined;

    const payload = {
      userId: user.id,
      type: draft.category,
      title: draft.title,
      description: draft.detail,
      city: draft.city,
      areas: draft.areas,
      minArea: draft.minArea,
      maxBudget: draft.maxBudget,
      propertyTypes: [draft.propertyType],
      roomCounts: draft.roomCounts,
      cardProfileCriteria,
      priceCurrency: draft.currency,
      urgency: draft.urgency,
      tags: [`Talep Türü:${draft.requestIntent}`],
    } as NetworkCreateInput;

    const quote = await this.quoteNetworkRequestPublish(user.id, payload);
    const now = Date.now();

    const plan: PendingNetworkRequestCreation = {
      planId: randomUUID(),
      userId: user.id,
      createdAt: now,
      expiresAt: now + PENDING_ACTION_TTL_MS,
      sourceModule,
      sourceText,
      payload,
      ...quote,
    };

    await this.savePending(user.id, PENDING_NETWORK_KIND, plan);

    this.audit(
      user,
      sourceModule,
      "network_request_create_prepare",
      "allowed",
    );

    return {
      handled: true,
      success: true,
      action: "network_request_create",
      requiresConfirmation: true,
      message: this.networkPublishConfirmMessage(plan),
    };
  }

  // Güncel DB ücreti (COST_TALEP_YAYIN + acilse COST_TALEP_ACIL_EK) ve varsayılan cüzdan kaynağı.
  private async quoteNetworkRequestPublish(
    userId: string,
    payload: NetworkCreateInput,
  ) {
    const isUrgent = String(payload.urgency || "").toUpperCase() === "ACIL";
    const baseCostPk = await readCost(this.prisma, "COST_TALEP_YAYIN");
    const urgentExtraPk = isUrgent
      ? await readCost(this.prisma, "COST_TALEP_ACIL_EK")
      : 0;
    const wallet = await resolveOfficeWallet(this.prisma, userId, {});

    return {
      costPk: baseCostPk + urgentExtraPk,
      baseCostPk,
      urgentExtraPk,
      walletSource: wallet.walletSource,
      walletOfficeId: wallet.walletOfficeId,
      walletLabel:
        wallet.walletSource === "OFFICE" ? "ofis cüzdanı" : "kişisel cüzdan",
    };
  }

  private networkPublishConfirmMessage(
    plan: PendingNetworkRequestCreation,
  ): string {
    const payload = plan.payload;
    const budget = payload?.maxBudget
      ? `, en çok ${payload.maxBudget} ${payload.priceCurrency || "TRY"}`
      : "";
    const summary = [payload?.title, payload?.city].filter(Boolean).join(" · ");

    return `Bu talep Talep Merkezi'nde yayınlanacak${summary ? ` (${summary}${budget})` : ""}. Ücret: ${plan.costPk} PK (cüzdan: ${plan.walletLabel}). Onaylıyor musunuz? 5 dakika içinde yalnızca “Onayla” deyin. Vazgeçmek için “İptal” deyin.`;
  }

  // Plan tek kez tüketilir: DB'de AKTIF→KAPANDI geçişini yalnız bir çağrı kazanır.
  private async claimNetworkPlan(userId: string, planId: string): Promise<boolean> {
    const result = await this.prisma.linaTaslak.updateMany({
      where: {
        kullaniciId: userId,
        tur: PENDING_NETWORK_KIND,
        durum: "AKTIF",
        alanlar: { path: ["planId"], equals: planId },
      },
      data: { durum: "KAPANDI" },
    });

    return result.count === 1;
  }

  private async publishNetworkRequestPlan(
    user: LinaResolvedUser,
    sourceModule: LinaActionSourceModule,
    plan: PendingNetworkRequestCreation,
  ): Promise<LinaActionExecutionResult> {
    if (!plan.payload) {
      await this.dropPending(user.id, PENDING_NETWORK_KIND);

      return {
        handled: true,
        success: false,
        message:
          "Bekleyen Talep Merkezi taslağı güncel değil. Talebi yeniden kaydetmeyi isteyin.",
      };
    }

    // Ücret veya cüzdan onaydan sonra değiştiyse yayınlama; yeni tutarla tekrar onay iste.
    const quote = await this.quoteNetworkRequestPublish(user.id, plan.payload);

    if (
      quote.costPk !== plan.costPk ||
      quote.walletSource !== plan.walletSource ||
      quote.walletOfficeId !== (plan.walletOfficeId ?? null)
    ) {
      const now = Date.now();
      const renewed: PendingNetworkRequestCreation = {
        ...plan,
        ...quote,
        planId: randomUUID(),
        createdAt: now,
        expiresAt: now + PENDING_ACTION_TTL_MS,
      };

      await this.savePending(user.id, PENDING_NETWORK_KIND, renewed);
      this.audit(
        user,
        sourceModule,
        "network_request_create_reprice",
        "blocked",
      );

      return {
        handled: true,
        success: false,
        action: "network_request_create",
        requiresConfirmation: true,
        message: `Ücret veya cüzdan bilgisi değişti, yayınlanmadı. ${this.networkPublishConfirmMessage(renewed)}`,
      };
    }

    if (!plan.planId || !(await this.claimNetworkPlan(user.id, plan.planId))) {
      return {
        handled: true,
        success: false,
        message: "Bu talep için onay zaten işlendi.",
      };
    }

    assertLinaBudget();
    const post = await this.networkService.create(plan.payload, user.id);

    this.audit(
      user,
      sourceModule,
      "network_request_create",
      "success",
    );

    return {
      handled: true,
      success: true,
      message: `Talebiniz Talep Merkezi'nde yayınlandı: ${plan.payload.title}. Ücret: ${plan.costPk} PK.`,
      data: post,
    };
  }

  private findNetworkRequestSourceText(
    history: LinaActionHistoryItem[],
    currentMessage: string,
  ): string | null {
    const currentNormalized = this.normalize(currentMessage);

    const candidates = [...history]
      .reverse()
      .filter((item) => item.role === "user")
      .map((item) => String(item.content || "").trim())
      .filter(Boolean)
      .filter((item) => this.normalize(item) !== currentNormalized);

    for (const candidate of candidates) {
      const normalized = this.normalize(candidate);

      if (
        normalized.includes("talep merkezi") ||
        normalized.includes("havuz portfoy") ||
        this.isConfirmationWord(candidate) ||
        this.isCancellationWord(candidate)
      ) {
        continue;
      }

      const hasPropertySignal =
        /(daire|villa|rezidans|mustakil|arsa|tarla|dukkan|ofis|fabrika|depo|otel|proje)/.test(
          normalized,
        );
      const hasDemandSignal =
        /(ariyorum|satilik|kiralik|butce|tl|₺|milyon|bin|\d+\s*\+\s*\d+)/.test(
          normalized,
        );

      if (hasPropertySignal && hasDemandSignal) {
        return candidate;
      }
    }

    return null;
  }

  private looksLikePlatformAction(message: string): boolean {
    const normalized = this.normalize(message);

    return (
      /(ekle|kaydet|olustur|guncelle|degistir|sil|tamamla|iptal et|not ekle|gorev ekle)/.test(
        normalized,
      ) &&
      /(crm|musteri|forum|network|portfoy|havuz|gorev|mesaj)/.test(normalized)
    );
  }

  private isInformationalQuestion(message: string): boolean {
    const normalized = this.normalize(message);

    return (
      normalized.includes("nasil ") ||
      normalized.endsWith(" nasil") ||
      normalized.includes("miyim") ||
      normalized.includes("miyiz") ||
      normalized.includes("mumkun mu") ||
      normalized.includes("ne yapmaliyim") ||
      normalized.includes("anlat")
    );
  }

  private isCrmCustomerListCommand(message: string): boolean {
    const normalized = this.normalize(message);

    return (
      normalized.includes("crm") &&
      (
        normalized.includes("musterilerimi listele") ||
        normalized.includes("musterileri listele") ||
        normalized.includes("musteri listesi") ||
        normalized.includes("kac musterim") ||
        normalized.includes("musteri sayim") ||
        normalized.includes("crm ozeti")
      )
    );
  }

  private isCrmCustomerFindCommand(message: string): boolean {
    const normalized = this.normalize(message);

    return (
      /(crm|musteri)/.test(normalized) &&
      /(bul|goster|getir|ara)/.test(normalized) &&
      !/(gorev|aktivite|not ekle|durumunu|statusunu)/.test(normalized)
    );
  }

  private isCrmCustomerDeleteCommand(message: string): boolean {
    const normalized = this.normalize(message);

    return (
      /(crm|musteri)/.test(normalized) &&
      /(sil|kaldir)/.test(normalized) &&
      !/(gorev|aktivite|not|ilgi|talep)/.test(normalized)
    );
  }

  private isCrmStatusUpdateCommand(message: string): boolean {
    const normalized = this.normalize(message);

    return (
      /(crm|musteri)/.test(normalized) &&
      /(durum|status|asama)/.test(normalized) &&
      /(guncelle|degistir|yap|al)/.test(normalized)
    );
  }

  private isCrmTaskCreateCommand(message: string): boolean {
    const normalized = this.normalize(message);

    return (
      normalized.includes("gorev") &&
      /(ekle|olustur|kaydet|hatirlat)/.test(normalized) &&
      /(musteri|crm|icin)/.test(normalized)
    );
  }

  private isCrmActivityCreateCommand(message: string): boolean {
    const normalized = this.normalize(message);

    return (
      /(not ekle|aktivite ekle|gorusme ekle|telefon gorusmesi|whatsapp gorusmesi|yer gosterimi ekle|teklif ekle)/.test(
        normalized,
      ) &&
      /(musteri|crm|icin|ile)/.test(normalized)
    );
  }

  private isCrmCustomerUpdateCommand(message: string): boolean {
    const raw = String(message || "").trim();
    const normalized = this.normalize(message);

    const hasUpdateField =
      /(telefon|e[- ]?posta|email|sehir|il|butce|not)/.test(normalized);

    const hasUpdateVerb =
      /(guncelle|degistir|duzelt)/.test(normalized);

    const hasExplicitCrmContext =
      /(crm|musteri)/.test(normalized);

    const hasNamedPossessiveTarget =
      /^.+?['’](?:nın|nin|nun|nün|ın|in|un|ün)\s+(?:telefon(?:u|unu)?|e[- ]?posta(?:sı|si)?|email(?:i)?|şehir(?:i)?|sehir(?:i)?|il(?:i)?|bütçe(?:si)?|butce(?:si)?|not(?:u)?)\b/iu.test(
        raw,
      );

    return (
      hasUpdateField &&
      hasUpdateVerb &&
      (hasExplicitCrmContext || hasNamedPossessiveTarget)
    );
  }

  private async listCrmCustomers(
    user: LinaResolvedUser,
    sourceModule: LinaActionSourceModule,
  ): Promise<LinaActionExecutionResult> {
    const customers = (await this.crmService.getCustomers(
      user.id,
      user.role,
    )) as CustomerLike[];

    const firstCustomers = customers.slice(0, 10);
    const lines = firstCustomers.map((customer, index) => {
      const fullName = this.customerFullName(customer);
      const phone = customer.phone ? ` — ${customer.phone}` : "";
      return `${index + 1}. ${fullName}${phone}`;
    });

    const suffix =
      customers.length > firstCustomers.length
        ? `\n\nİlk 10 kayıt gösterildi. Toplam ${customers.length} CRM kaydınız var.`
        : `\n\nToplam ${customers.length} CRM kaydınız var.`;

    this.audit(user, sourceModule, "crm_customer_list", "success");

    return {
      handled: true,
      success: true,
      action: "crm_customer_list",
      message:
        customers.length === 0
          ? "CRM’inizde henüz müşteri kaydı bulunmuyor."
          : `CRM müşteri listeniz:\n\n${lines.join("\n")}${suffix}`,
      data: {
        total: customers.length,
        customers: firstCustomers.map((customer) => ({
          id: customer.id,
          firstName: customer.firstName,
          lastName: customer.lastName,
          phone: customer.phone,
          email: customer.email,
          city: customer.city,
          status: customer.status,
        })),
      },
    };
  }

  private async findCrmCustomer(
    message: string,
    user: LinaResolvedUser,
    sourceModule: LinaActionSourceModule,
  ): Promise<LinaActionExecutionResult> {
    const customerName = this.extractCustomerName(message, [
      "bul",
      "göster",
      "goster",
      "getir",
      "ara",
    ]);

    if (!customerName) {
      return this.missingCustomerName();
    }

    const resolution = await this.resolveCustomer(customerName, user);

    if (!("customer" in resolution)) {
      return resolution;
    }

    const customer = resolution.customer;
    const taskCount = Array.isArray(customer.tasks) ? customer.tasks.length : 0;

    this.audit(user, sourceModule, "crm_customer_find", "success");

    return {
      handled: true,
      success: true,
      action: "crm_customer_find",
      message: [
        `${this.customerFullName(customer)} CRM kaydı bulundu.`,
        customer.phone ? `Telefon: ${customer.phone}` : null,
        customer.email ? `E-posta: ${customer.email}` : null,
        customer.city ? `Şehir: ${customer.city}` : null,
        customer.status ? `Durum: ${this.customerStatusLabel(customer.status)}` : null,
        typeof customer.budget === "number"
          ? `Bütçe: ${new Intl.NumberFormat("tr-TR").format(customer.budget)} ₺`
          : null,
        `Bekleyen görev: ${taskCount}`,
        customer.notes ? `Not: ${customer.notes}` : null,
      ]
        .filter(Boolean)
        .join("\n"),
      data: customer,
    };
  }

  private async updateCrmCustomer(
    message: string,
    user: LinaResolvedUser,
    sourceModule: LinaActionSourceModule,
  ): Promise<LinaActionExecutionResult> {
    const customerName = this.extractCustomerName(message, [
      "güncelle",
      "guncelle",
      "değiştir",
      "degistir",
      "düzelt",
      "duzelt",
    ]);

    if (!customerName) {
      return this.missingCustomerName();
    }

    const resolution = await this.resolveCustomer(customerName, user);

    if (!("customer" in resolution)) {
      return resolution;
    }

    const fields = this.extractCustomerFields(message);
    const data: Record<string, unknown> = {};

    if (fields.phone) data.phone = fields.phone;
    if (fields.email) data.email = fields.email;
    if (fields.city) data.city = fields.city;
    if (typeof fields.budget === "number") data.budget = fields.budget;
    if (fields.notes) data.notes = fields.notes;

    if (Object.keys(data).length === 0) {
      return {
        handled: true,
        success: false,
        message:
          "Güncellenecek alanı anlayamadım. Telefon, e-posta, şehir, bütçe veya not bilgisini açıkça söyleyin.",
      };
    }

    assertLinaBudget();
    const updated = (await this.crmService.updateCustomer(
      resolution.customer.id,
      user.id,
      user.role,
      data,
    )) as CustomerLike;

    this.audit(user, sourceModule, "crm_customer_update", "success");

    return {
      handled: true,
      success: true,
      action: "crm_customer_update",
      message: `${this.customerFullName(updated)} CRM kaydı güncellendi.`,
      data: updated,
    };
  }

  private async updateCrmCustomerStatus(
    message: string,
    user: LinaResolvedUser,
    sourceModule: LinaActionSourceModule,
  ): Promise<LinaActionExecutionResult> {
    const customerName = this.extractCustomerName(message, [
      "durum",
      "status",
      "aşama",
      "asama",
    ]);

    if (!customerName) {
      return this.missingCustomerName();
    }

    const status = this.extractCustomerStatus(message);

    if (!status) {
      return {
        handled: true,
        success: false,
        message:
          "CRM durumunu anlayamadım. Kullanılabilir durumlar: Yeni Lead, İlk Görüşme, Portföy Gönderildi, Yer Gösterimi, Teklif Süreci, Pazarlık, Kapandı ve Kaybedildi.",
      };
    }

    const resolution = await this.resolveCustomer(customerName, user);

    if (!("customer" in resolution)) {
      return resolution;
    }

    assertLinaBudget();
    const updated = (await this.crmService.updateStatus(
      resolution.customer.id,
      user.id,
      user.role,
      status,
    )) as CustomerLike;

    this.audit(user, sourceModule, "crm_customer_status_update", "success");

    return {
      handled: true,
      success: true,
      action: "crm_customer_status_update",
      message: `${this.customerFullName(updated)} CRM durumu “${this.customerStatusLabel(status)}” olarak güncellendi.`,
      data: updated,
    };
  }

  private async prepareDeleteCrmCustomer(
    message: string,
    user: LinaResolvedUser,
    sourceModule: LinaActionSourceModule,
    confirmedDelete?: LinaGateConfirmedDelete,
  ): Promise<LinaActionExecutionResult> {
    const customerName = this.extractCustomerName(message, [
      "sil",
      "kaldır",
      "kaldir",
    ]);

    if (!customerName) {
      return this.missingCustomerName();
    }

    const resolution = await this.resolveCustomer(customerName, user);

    if (!("customer" in resolution)) {
      return resolution;
    }

    const fullName = this.customerFullName(resolution.customer);
    if (confirmedDelete?.planId && confirmedDelete.userId === user.id &&
      confirmedDelete.sourceModule === sourceModule && confirmedDelete.command === message) {
      return this.deleteCrmCustomer(resolution.customer.id, fullName, user, sourceModule);
    }
    const now = Date.now();

    await this.savePending(user.id, PENDING_ACTION_KIND, {
      type: "crm_customer_delete",
      userId: user.id,
      createdAt: now,
      expiresAt: now + PENDING_ACTION_TTL_MS,
      payload: {
        customerId: resolution.customer.id,
        customerName: fullName,
      },
    });

    this.audit(
      user,
      sourceModule,
      "crm_customer_delete_prepare",
      "allowed",
      undefined,
      2,
    );

    return {
      handled: true,
      success: true,
      action: "crm_customer_delete",
      requiresConfirmation: true,
      message: `${fullName} adlı CRM kaydı ve bağlı CRM verileri silinecek. Onaylamak için 5 dakika içinde yalnızca “Onayla” deyin. Vazgeçmek için “İptal” deyin.`,
    };
  }

  private async createCrmTask(
    message: string,
    user: LinaResolvedUser,
    sourceModule: LinaActionSourceModule,
  ): Promise<LinaActionExecutionResult> {
    const customerName = this.extractCustomerName(message, [
      "görev",
      "gorev",
      "hatırlat",
      "hatirlat",
    ]);

    if (!customerName) {
      return this.missingCustomerName();
    }

    const resolution = await this.resolveCustomer(customerName, user);

    if (!("customer" in resolution)) {
      return resolution;
    }

    const title = this.extractTaskTitle(message, customerName);
    const dueDate = this.extractDueDate(message);

    assertLinaBudget();
    const task = await this.crmService.addTask(
      resolution.customer.id,
      user.id,
      user.role,
      {
        title,
        dueDate: dueDate?.toISOString(),
      },
    );

    this.audit(user, sourceModule, "crm_task_create", "success");

    const dueText = dueDate
      ? ` Tarih: ${new Intl.DateTimeFormat("tr-TR", {
          dateStyle: "medium",
          timeStyle: "short",
          timeZone: "Europe/Istanbul",
        }).format(dueDate)}.`
      : "";

    return {
      handled: true,
      success: true,
      action: "crm_task_create",
      message: `${this.customerFullName(resolution.customer)} için “${title}” görevi oluşturuldu.${dueText}`,
      data: task,
    };
  }

  private async createCrmActivity(
    message: string,
    user: LinaResolvedUser,
    sourceModule: LinaActionSourceModule,
  ): Promise<LinaActionExecutionResult> {
    const customerName = this.extractCustomerName(message, [
      "not",
      "aktivite",
      "görüşme",
      "gorusme",
      "telefon",
      "whatsapp",
      "yer gösterimi",
      "yer gosterimi",
      "teklif",
    ]);

    if (!customerName) {
      return this.missingCustomerName();
    }

    const resolution = await this.resolveCustomer(customerName, user);

    if (!("customer" in resolution)) {
      return resolution;
    }

    const note = this.extractActivityNote(message);

    if (!note) {
      return {
        handled: true,
        success: false,
        message:
          "Aktivite notunu anlayamadım. Örnek: “Ahmet Yılmaz için telefon görüşmesi ekle: Cuma günü tekrar aranacak.”",
      };
    }

    const type = this.extractActivityType(message);
    assertLinaBudget();
    const activity = await this.crmService.addActivity(
      resolution.customer.id,
      user.id,
      user.role,
      {
        type,
        note,
      },
    );

    this.audit(user, sourceModule, "crm_activity_create", "success");

    return {
      handled: true,
      success: true,
      action: "crm_activity_create",
      message: `${this.customerFullName(resolution.customer)} CRM kaydına ${this.activityTypeLabel(type)} aktivitesi eklendi.`,
      data: activity,
    };
  }

  private async handlePendingConfirmation(
    message: string,
    user: LinaResolvedUser,
    sourceModule: LinaActionSourceModule,
  ): Promise<LinaActionExecutionResult> {
    const pendingNetwork =
      await this.loadPending<PendingNetworkRequestCreation>(user.id, PENDING_NETWORK_KIND);

    if (pendingNetwork) {
      if (pendingNetwork.expiresAt < Date.now()) {
        await this.dropPending(user.id, PENDING_NETWORK_KIND);

        if (
          this.isConfirmationWord(message) ||
          this.isCancellationWord(message)
        ) {
          return {
            handled: true,
            success: false,
            message:
              "Bekleyen Talep Merkezi kayıt taslağının onay süresi doldu. Talebi yeniden kaydetmeyi isteyin.",
          };
        }
      } else if (this.isCancellationWord(message)) {
        await this.dropPending(user.id, PENDING_NETWORK_KIND);

        this.audit(
          user,
          pendingNetwork.sourceModule || sourceModule,
          "network_request_create_cancel",
          "success",
        );

        return {
          handled: true,
          success: true,
          action: "confirmation_cancelled",
          message: "Bekleyen Talep Merkezi kayıt taslağı iptal edildi.",
        };
      } else if (this.isConfirmationWord(message)) {
        return await this.publishNetworkRequestPlan(
          user,
          pendingNetwork.sourceModule || sourceModule,
          pendingNetwork,
        );
      }
    }

    const pending = await this.loadPending<LinaPendingAction>(user.id, PENDING_ACTION_KIND);

    if (!pending) {
      return { handled: false };
    }

    if (pending.expiresAt < Date.now()) {
      await this.dropPending(user.id, PENDING_ACTION_KIND);

      if (
        this.isConfirmationWord(message) ||
        this.isCancellationWord(message)
      ) {
        return {
          handled: true,
          success: false,
          message:
            "Bekleyen işlem onay süresi doldu. İşlemi yeniden söyleyin.",
        };
      }

      return { handled: false };
    }

    if (this.isCancellationWord(message)) {
      await this.dropPending(user.id, PENDING_ACTION_KIND);
      this.audit(
        user,
        sourceModule,
        "lina_action_cancel",
        "success",
      );

      return {
        handled: true,
        success: true,
        action: "confirmation_cancelled",
        message: "Bekleyen işlem iptal edildi.",
      };
    }

    if (!this.isConfirmationWord(message)) {
      return { handled: false };
    }

    if (pending.type === "crm_customer_delete") {
      const result = await this.deleteCrmCustomer(pending.payload.customerId, pending.payload.customerName, user, sourceModule);
      await this.dropPending(user.id, PENDING_ACTION_KIND);
      return result;
    }

    return { handled: false };
  }

  private async deleteCrmCustomer(customerId: string, customerName: string, user: LinaResolvedUser,
    sourceModule: LinaActionSourceModule): Promise<LinaActionExecutionResult> {
    assertLinaBudget();
    await this.crmService.deleteCustomer(customerId, user.id, user.role);
    this.audit(user, sourceModule, 'crm_customer_delete', 'success', undefined, 3);
    return { handled: true, success: true, action: 'crm_customer_delete', message: `${customerName} adlı CRM kaydı silindi.` };
  }

  private async resolveCustomer(
    nameQuery: string,
    user: LinaResolvedUser,
  ): Promise<
    | { customer: CustomerLike }
    | LinaActionExecutionResult
  > {
    const customers = (await this.crmService.getCustomers(
      user.id,
      user.role,
    )) as CustomerLike[];
    const normalizedQuery = this.normalize(nameQuery);

    const exactMatches = customers.filter(
      (customer) =>
        this.normalize(this.customerFullName(customer)) === normalizedQuery,
    );

    if (exactMatches.length === 1) {
      const customer = (await this.crmService.getCustomer(
        exactMatches[0].id,
        user.id,
        user.role,
      )) as CustomerLike;

      return { customer };
    }

    const partialMatches = customers.filter((customer) => {
      const fullName = this.normalize(this.customerFullName(customer));
      return (
        fullName.includes(normalizedQuery) ||
        normalizedQuery.includes(fullName)
      );
    });

    if (partialMatches.length === 1) {
      const customer = (await this.crmService.getCustomer(
        partialMatches[0].id,
        user.id,
        user.role,
      )) as CustomerLike;

      return { customer };
    }

    if (partialMatches.length > 1) {
      const names = partialMatches
        .slice(0, 5)
        .map((customer) => this.customerFullName(customer))
        .join(", ");

      return {
        handled: true,
        success: false,
        message: `Birden fazla eşleşen CRM kaydı bulundu: ${names}. Lütfen ad ve soyadı birlikte söyleyin.`,
      };
    }

    return {
      handled: true,
      success: false,
      message: `${nameQuery} adına ait CRM kaydı bulunamadı.`,
    };
  }

  private extractCustomerName(
    message: string,
    stopWords: string[],
  ): string | null {
    const text = String(message || "")
      .replace(/\s+/g, " ")
      .trim();

    const patterns: RegExp[] = [
      /^(.+?)\s+CRM\s+kayd(?:ını|ini|unu|ünü)\s+(?:sil|kaldır|kaldir)\b/iu,

        /^(.+?)['’](?:nın|nin|nun|nün|ın|in|un|ün)\s+(?:telefon(?:u|unu)?|e[- ]?posta(?:sı|si)?|email(?:i)?|şehir(?:i)?|sehir(?:i)?|il(?:i)?|bütçe(?:si)?|butce(?:si)?|not(?:u)?)\b/iu,
      /(?:crm['’]?(?:e|ye|de|den)?\s+)(.+?)(?:\s+(?:adlı|isimli)\s+)?(?:müşteri(?:yi|si)?\s+)?(?:ekle|kaydet|oluştur|olustur|sil|kaldır|kaldir|bul|göster|goster|getir|ara)\b/i,
      /^(.+?)(?:['’](?:ı|i|u|ü|yi|yı|yu|yü|ın|in|un|ün))?\s+(?:adlı|isimli\s+)?(?:müşteri(?:yi|si)?\s+)?crm['’]?(?:e|ye|de|den)?\s+(?:ekle|kaydet|oluştur|olustur|sil|kaldır|kaldir|bul|göster|goster|getir|ara)\b/i,
      /^(.+?)(?:['’](?:ın|in|un|ün|a|e|ya|ye))?\s+(?:için\s+)?(?:görev|gorev|not|aktivite|telefon görüşmesi|telefon gorusmesi|whatsapp görüşmesi|whatsapp gorusmesi|yer gösterimi|yer gosterimi|teklif)\b/i,
      /(?:müşteri|crm kaydı|crm kaydi)\s+(.+?)(?:['’](?:ın|in|un|ün|ı|i|u|ü|a|e|ya|ye))?\s+(?:durum|status|aşama|asama|telefon|e[- ]?posta|email|şehir|sehir|il|bütçe|butce|not)\b/i,
    ];

    for (const pattern of patterns) {
      const match = text.match(pattern);
      const candidate = this.cleanExtractedName(match?.[1]);

      if (candidate) {
        return candidate;
      }
    }

    const normalizedStops = stopWords
      .map((word) => this.escapeRegExp(word))
      .join("|");

    const fallbackPatterns = [
      new RegExp(
        `(?:müşteri|crm kaydı|crm kaydi)\\s+(.+?)(?:['’](?:ın|in|un|ün|ı|i|u|ü|a|e|ya|ye))?\\s+(?:${normalizedStops})\\b`,
        "i",
      ),
      new RegExp(
        `^(.+?)(?:['’](?:ın|in|un|ün|ı|i|u|ü|a|e|ya|ye))?\\s+.*?(?:${normalizedStops})\\b`,
        "i",
      ),
    ];

    for (const pattern of fallbackPatterns) {
      const match = text.match(pattern);
      const candidate = this.cleanExtractedName(match?.[1]);

      if (candidate) {
        return candidate;
      }
    }

    return null;
  }

  private cleanExtractedName(value?: string): string | null {
    if (!value) {
      return null;
    }

    const cleaned = value
      .replace(
        /\b(?:adlı|isimli|müşteri|musteri|crm|kaydı|kaydi|için|icin|telefonu|telefon|e[- ]?postası|emaili|şehri|sehri|bütçesi|butcesi)\b/gi,
        " ",
      )
      .replace(/['’](?:ı|i|u|ü|yi|yı|yu|yü|ın|in|un|ün|a|e|ya|ye)$/i, "")
      .replace(/[,:;.!?]+$/g, "")
      .replace(/\s+/g, " ")
      .trim();

    const words = cleaned.split(" ").filter(Boolean);

    if (words.length < 1 || words.length > 5) {
      return null;
    }

    if (
      words.some((word) =>
        /^(ekle|kaydet|olustur|oluştur|sil|kaldir|kaldır|bul|goster|göster|getir|ara)$/i.test(
          word,
        ),
      )
    ) {
      return null;
    }

    return cleaned;
  }

  private splitPersonName(
    fullName: string,
  ): { firstName: string; lastName: string } | null {
    const parts = fullName
      .split(/\s+/)
      .map((part) => part.trim())
      .filter(Boolean);

    if (parts.length < 2) {
      return null;
    }

    return {
      firstName: this.titleCase(parts.slice(0, -1).join(" ")),
      lastName: this.titleCase(parts[parts.length - 1] || ""),
    };
  }

  private extractCustomerFields(message: string): ParsedCustomerFields {
    const phoneMatch = message.match(
      /(?:telefon(?:u|unu)?|gsm|cep(?: telefonu)?)\s*(?::|=|olarak)?\s*(\+?90\s*)?0?5\d{2}[\s.-]?\d{3}[\s.-]?\d{2}[\s.-]?\d{2}/i,
    );
    const rawPhone = phoneMatch?.[0].match(
      /(\+?90\s*)?0?5\d{2}[\s.-]?\d{3}[\s.-]?\d{2}[\s.-]?\d{2}/,
    )?.[0];

    const emailMatch = message.match(
      /(?:e[- ]?posta(?:sı|si|sini)?|email(?:i|ini)?)\s*(?::|=|olarak)?\s*([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})/i,
    );

    const cityMatch = message.match(
      /(?:şehir(?:i|ini)?|sehir(?:i|ini)?|il(?:i|ini)?)\s*(?::|=|olarak)?\s*([A-Za-zÇĞİÖŞÜçğıöşü\s-]{2,30})(?=\s*(?:,|\.|telefon|e[- ]?posta|email|bütçe|butce|not|$))/i,
    );

    const budgetMatch = message.match(
      /(?:bütçe(?:si|sini)?|butce(?:si|sini)?)\s*(?::|=|olarak)?\s*([\d.,]+)\s*(milyon|bin)?/i,
    );

    const noteMatch = message.match(
      /(?:not(?:u|unu)?|açıklama(?:sı|sini)?|aciklama(?:si|sini)?)\s*(?::|=|olarak)?\s*(.+)$/i,
    );

    return {
      phone: rawPhone ? this.normalizePhone(rawPhone) : undefined,
      email: emailMatch?.[1]?.trim().toLocaleLowerCase("tr-TR"),
      city: cityMatch?.[1]?.trim(),
      budget: budgetMatch
        ? this.parseTurkishMoney(budgetMatch[1], budgetMatch[2])
        : undefined,
      notes: noteMatch?.[1]?.trim(),
    };
  }

  private extractCustomerStatus(message: string): CustomerStatus | null {
    const normalized = this.normalize(message);
    const statusMap: Array<[RegExp, CustomerStatus]> = [
      [/(kaybedildi|kayip|olumsuz)/, CustomerStatus.KAYBEDILDI],
      [/(kapandi|satis tamamlandi|islem tamamlandi)/, CustomerStatus.KAPANDI],
      [/(pazarlik)/, CustomerStatus.PAZARLIK],
      [/(teklif sureci|teklif)/, CustomerStatus.TEKLIF_SURECI],
      [/(yer gosterimi)/, CustomerStatus.YER_GOSTERIMI],
      [/(portfoy gonderildi|portfolyo gonderildi)/, CustomerStatus.PORTFOLYO_GONDERILDI],
      [/(ilk gorusme|gorusme yapildi)/, CustomerStatus.ILK_GORUSME],
      [/(yeni lead|yeni musteri|yeni)/, CustomerStatus.YENI_LEAD],
    ];

    for (const [pattern, status] of statusMap) {
      if (pattern.test(normalized)) {
        return status;
      }
    }

    return null;
  }

  private extractTaskTitle(message: string, customerName: string): string {
    const afterColon = message.split(/[:：]/).slice(1).join(":").trim();

    if (afterColon) {
      return this.cleanTaskTitle(afterColon);
    }

    const withoutName = message
      .replace(new RegExp(this.escapeRegExp(customerName), "i"), " ")
      .replace(
        /\b(?:crm|müşteri|musteri|için|icin|görev|gorev|ekle|oluştur|olustur|kaydet|hatırlat|hatirlat|bugün|bugun|yarın|yarin|öbür gün|obur gun|saat|tarih)\b/gi,
        " ",
      )
      .replace(/\b\d{1,2}[:.]\d{2}\b/g, " ")
      .replace(/\b\d{1,2}[./-]\d{1,2}[./-]\d{2,4}\b/g, " ")
      .replace(/\s+/g, " ")
      .trim();

    return this.cleanTaskTitle(withoutName || "Müşteri takibi");
  }

  private cleanTaskTitle(value: string): string {
    const cleaned = value
      .replace(/\s+/g, " ")
      .replace(/[.!?]+$/g, "")
      .trim();

    if (!cleaned) {
      return "Müşteri takibi";
    }

    return cleaned.length > 120 ? cleaned.slice(0, 120).trim() : cleaned;
  }

  private extractDueDate(message: string): Date | undefined {
    const normalized = this.normalize(message);
    const timeMatch = message.match(/\b(?:saat\s*)?([01]?\d|2[0-3])[:.]([0-5]\d)\b/i);
    const hour = timeMatch ? Number(timeMatch[1]) : 9;
    const minute = timeMatch ? Number(timeMatch[2]) : 0;

    const explicitDateMatch = message.match(
      /\b([0-3]?\d)[./-]([01]?\d)[./-](\d{2}|\d{4})\b/,
    );

    if (explicitDateMatch) {
      const day = Number(explicitDateMatch[1]);
      const month = Number(explicitDateMatch[2]);
      const rawYear = Number(explicitDateMatch[3]);
      const year = rawYear < 100 ? 2000 + rawYear : rawYear;

      return this.createIstanbulDate(year, month, day, hour, minute);
    }

    let offsetDays: number | null = null;

    if (normalized.includes("obur gun")) offsetDays = 2;
    else if (normalized.includes("yarin")) offsetDays = 1;
    else if (normalized.includes("bugun")) offsetDays = 0;

    if (offsetDays === null && !timeMatch) {
      return undefined;
    }

    const now = new Date();
    const istanbulNow = new Date(now.getTime() + 3 * 60 * 60 * 1000);
    const year = istanbulNow.getUTCFullYear();
    const month = istanbulNow.getUTCMonth() + 1;
    const day = istanbulNow.getUTCDate() + (offsetDays ?? 0);

    return this.createIstanbulDate(year, month, day, hour, minute);
  }

  private createIstanbulDate(
    year: number,
    month: number,
    day: number,
    hour: number,
    minute: number,
  ): Date {
    return new Date(Date.UTC(year, month - 1, day, hour - 3, minute, 0, 0));
  }

  private extractActivityNote(message: string): string | null {
    const afterColon = message.split(/[:：]/).slice(1).join(":").trim();

    if (afterColon) {
      return afterColon.slice(0, 1000);
    }

    const match = message.match(
      /(?:not ekle|aktivite ekle|görüşme ekle|gorusme ekle|telefon görüşmesi|telefon gorusmesi|whatsapp görüşmesi|whatsapp gorusmesi|yer gösterimi ekle|yer gosterimi ekle|teklif ekle)\s*(?:olarak)?\s+(.+)$/i,
    );

    const note = match?.[1]
      ?.replace(/[.!?]+$/g, "")
      .replace(/\s+/g, " ")
      .trim();

    return note ? note.slice(0, 1000) : null;
  }

  private extractActivityType(message: string): ActivityType {
    const normalized = this.normalize(message);

    if (normalized.includes("whatsapp")) return ActivityType.WHATSAPP;
    if (normalized.includes("email") || normalized.includes("e posta")) {
      return ActivityType.EMAIL;
    }
    if (normalized.includes("yer gosterimi")) return ActivityType.YER_GOSTERIMI;
    if (normalized.includes("teklif")) return ActivityType.TEKLIF;
    if (normalized.includes("telefon") || normalized.includes("gorusme")) {
      return ActivityType.TELEFON;
    }
    if (normalized.includes("not")) return ActivityType.NOT;

    return ActivityType.DIGER;
  }

  private isConfirmationWord(message: string): boolean {
    return /^(onayla|kaydi onayla|kaydı onayla|onayliyorum|evet|tamam|devam et)$/i.test(
      this.normalize(message),
    );
  }

  private isCancellationWord(message: string): boolean {
    return /^(iptal|iptal et|vazgec|hayir)$/i.test(this.normalize(message));
  }

  private missingCustomerName(): LinaActionExecutionResult {
    return {
      handled: true,
      success: false,
      message:
        "İşlem yapılacak müşterinin adını ve soyadını anlayamadım. Lütfen ad ve soyadı birlikte söyleyin.",
    };
  }

  private customerFullName(customer: CustomerLike): string {
    return `${customer.firstName || ""} ${customer.lastName || ""}`
      .replace(/\s+/g, " ")
      .trim();
  }

  private customerStatusLabel(status: CustomerStatus): string {
    const labels: Record<CustomerStatus, string> = {
      YENI_LEAD: "Yeni Lead",
      ILK_GORUSME: "İlk Görüşme",
      PORTFOLYO_GONDERILDI: "Portföy Gönderildi",
      YER_GOSTERIMI: "Yer Gösterimi",
      TEKLIF_SURECI: "Teklif Süreci",
      PAZARLIK: "Pazarlık",
      KAPANDI: "Kapandı",
      KAYBEDILDI: "Kaybedildi",
    };

    return labels[status];
  }

  private activityTypeLabel(type: ActivityType): string {
    const labels: Record<ActivityType, string> = {
      TELEFON: "Telefon",
      WHATSAPP: "WhatsApp",
      EMAIL: "E-posta",
      YER_GOSTERIMI: "Yer Gösterimi",
      TEKLIF: "Teklif",
      NOT: "Not",
      DIGER: "Diğer",
    };

    return labels[type];
  }

  private normalize(value: string): string {
    return String(value || "")
      .trim()
      .toLocaleLowerCase("tr-TR")
      .replaceAll("ç", "c")
      .replaceAll("ğ", "g")
      .replaceAll("ı", "i")
      .replaceAll("ö", "o")
      .replaceAll("ş", "s")
      .replaceAll("ü", "u")
      .replace(/[’']/g, "")
      .replace(/[^\p{L}\p{N}@.+:/\-\s]/gu, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  private normalizePhone(value: string): string {
    const digits = this.onlyDigits(value);

    if (digits.startsWith("90") && digits.length === 12) {
      return `+${digits}`;
    }

    if (digits.length === 10 && digits.startsWith("5")) {
      return `0${digits}`;
    }

    return digits;
  }

  private onlyDigits(value: string): string {
    return String(value || "").replace(/\D/g, "");
  }

  private parseTurkishMoney(value: string, scale?: string): number | undefined {
    const normalizedScale = this.normalize(scale || "");
    const compact = String(value || "").replace(/\s+/g, "");
    let numericValue: number;

    if (compact.includes(",") && compact.includes(".")) {
      numericValue = Number(compact.replace(/\./g, "").replace(",", "."));
    } else if (compact.includes(",")) {
      const pieces = compact.split(",");
      numericValue =
        pieces[1]?.length === 3
          ? Number(compact.replace(/,/g, ""))
          : Number(compact.replace(",", "."));
    } else if (compact.includes(".")) {
      const pieces = compact.split(".");
      numericValue =
        pieces[1]?.length === 3
          ? Number(compact.replace(/\./g, ""))
          : Number(compact);
    } else {
      numericValue = Number(compact);
    }

    if (!Number.isFinite(numericValue)) {
      return undefined;
    }

    if (normalizedScale === "milyon") {
      return numericValue * 1_000_000;
    }

    if (normalizedScale === "bin") {
      return numericValue * 1_000;
    }

    return numericValue;
  }

  private titleCase(value: string): string {
    return value
      .toLocaleLowerCase("tr-TR")
      .split(/\s+/)
      .filter(Boolean)
      .map((part) => `${part.charAt(0).toLocaleUpperCase("tr-TR")}${part.slice(1)}`)
      .join(" ");
  }

  private escapeRegExp(value: string): string {
    return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  private audit(
    user: LinaResolvedUser,
    sourceModule: LinaActionSourceModule,
    action: string,
    result: "allowed" | "blocked" | "filtered" | "error" | "success",
    reason?: string,
    riskLevel: 0 | 1 | 2 | 3 | 4 = 0,
  ): void {
    this.linaAuditService.log({
      userId: user.id,
      role: user.role,
      module: sourceModule,
      action,
      result,
      reason,
      riskLevel,
    });
  }
}
